<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class TripFaq extends Model
{
    protected $table = 'trip_faqs';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
        'trip_id',
        'question',
        'answer',
        'sort_order',
    ];
    protected $casts = [
        'id' => 'integer',
        'trip_id' => 'integer',
        'sort_order' => 'integer',
    ];
    public function trip()
    {
        return $this->belongsTo(Trip::class, 'trip_id', 'id');
    }
}