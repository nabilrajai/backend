<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class Departure extends Model
{
    protected $table = 'departures';
    protected $primaryKey = 'id';
    use SoftDeletes;
    protected $fillable = [
        'public_id',
        'code',
        'trip_id',
        'start_at',
        'end_at',
        'capacity',
        'status',
        'guide_user_id',
        'vehicle_id',
        'guide_name',
        'guide_phone',
        'vehicle_label',
        'pickup_location_fr',
        'pickup_location_en',
        'price_mad',
        'notes_fr',
        'notes_en',
        'created_by',
    ];
    protected $casts = [
        'id' => 'integer',
        'trip_id' => 'integer',
        'start_at' => 'datetime',
        'end_at' => 'datetime',
        'capacity' => 'integer',
        'guide_user_id' => 'integer',
        'vehicle_id' => 'integer',
        'price_mad' => 'decimal:2',
        'created_by' => 'integer',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
        'deleted_at' => 'datetime',
    ];
    public function trip()
    {
        return $this->belongsTo(Trip::class, 'trip_id', 'id');
    }
}