<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class DeparturePresence extends Model
{
    protected $table = 'departure_presence';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
        'departure_id',
        'reservation_id',
        'traveler_id',
        'seat_number',
        'is_present',
        'pickup_point_1',
        'pickup_point_2',
        'dropoff_point',
        'checked_at',
        'checked_by',
        'notes',
    ];
    protected $casts = [
        'id' => 'integer',
        'departure_id' => 'integer',
        'reservation_id' => 'integer',
        'traveler_id' => 'integer',
        'is_present' => 'boolean',
        'checked_at' => 'datetime',
        'checked_by' => 'integer',
    ];
    public function departure()
    {
        return $this->belongsTo(Departure::class, 'departure_id', 'id');
    }
}