<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class DestinationTrip extends Model
{
    protected $table = 'destination_trips';
    // Composite-key table; use controller query methods for key-based operations.
    protected $primaryKey = null;
    public $incrementing = false;
    public $timestamps = false;
    protected $fillable = [
        'destination_id',
        'trip_id',
    ];
    protected $casts = [
        'destination_id' => 'integer',
        'trip_id' => 'integer',
    ];
    public function destination()
    {
        return $this->belongsTo(Destination::class, 'destination_id', 'id');
    }
}