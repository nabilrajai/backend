<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class ReservationTimeline extends Model
{
    protected $table = 'reservation_timeline';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
        'reservation_id',
        'category',
        'title',
        'description',
        'details',
        'author_user_id',
        'is_system',
    ];
    protected $casts = [
        'id' => 'integer',
        'reservation_id' => 'integer',
        'details' => 'array',
        'author_user_id' => 'integer',
        'is_system' => 'boolean',
        'created_at' => 'datetime',
    ];
    public function reservation()
    {
        return $this->belongsTo(Reservation::class, 'reservation_id', 'id');
    }
}