<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class GalleryPhoto extends Model
{
    protected $table = 'gallery_photos';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
        'gallery_id',
        'url',
        'caption',
        'uploaded_by',
        'is_cover',
        'sort_order',
    ];
    protected $casts = [
        'id' => 'integer',
        'gallery_id' => 'integer',
        'uploaded_by' => 'integer',
        'is_cover' => 'boolean',
        'sort_order' => 'integer',
        'created_at' => 'datetime',
    ];
    public function gallery()
    {
        return $this->belongsTo(Gallery::class, 'gallery_id', 'id');
    }
}