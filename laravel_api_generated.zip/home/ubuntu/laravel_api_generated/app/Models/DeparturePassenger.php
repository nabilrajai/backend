<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class DeparturePassenger extends Model
{
    protected $table = 'departure_passengers';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
        'departure_id',
        'reservation_id',
        'passenger_count',
        'phone',
        'paid',
        'notes',
    ];
    protected $casts = [
        'id' => 'integer',
        'departure_id' => 'integer',
        'reservation_id' => 'integer',
        'passenger_count' => 'integer',
        'paid' => 'boolean',
    ];
    public function departure()
    {
        return $this->belongsTo(Departure::class, 'departure_id', 'id');
    }
}