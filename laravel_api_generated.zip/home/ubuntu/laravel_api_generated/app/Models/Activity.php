<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class Activity extends Model
{
    protected $table = 'activities';
    protected $primaryKey = 'id';
    use SoftDeletes;
    protected $fillable = [
        'public_id',
        'name',
        'category',
        'location',
        'duration_minutes',
        'price_mad',
        'description',
        'rating',
        'reviews_count',
        'inclusions',
        'status',
        'created_by',
    ];
    protected $casts = [
        'id' => 'integer',
        'duration_minutes' => 'integer',
        'price_mad' => 'decimal:2',
        'rating' => 'decimal:2',
        'reviews_count' => 'integer',
        'inclusions' => 'array',
        'created_by' => 'integer',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
        'deleted_at' => 'datetime',
    ];
    public function user()
    {
        return $this->belongsTo(User::class, 'created_by', 'id');
    }
}