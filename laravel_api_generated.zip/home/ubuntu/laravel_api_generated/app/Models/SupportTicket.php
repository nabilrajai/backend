<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class SupportTicket extends Model
{
    protected $table = 'support_tickets';
    protected $primaryKey = 'id';
    protected $fillable = [
        'public_id',
        'ticket_number',
        'requester_user_id',
        'requester_name',
        'requester_email',
        'subject',
        'category',
        'priority',
        'status',
        'assigned_to',
        'description',
        'resolution',
        'resolved_at',
    ];
    protected $casts = [
        'id' => 'integer',
        'requester_user_id' => 'integer',
        'assigned_to' => 'integer',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
        'resolved_at' => 'datetime',
    ];
    public function user()
    {
        return $this->belongsTo(User::class, 'requester_user_id', 'id');
    }
}