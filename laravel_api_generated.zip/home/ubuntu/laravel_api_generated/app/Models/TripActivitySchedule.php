<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class TripActivitySchedule extends Model
{
    protected $table = 'trip_activity_schedule';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
        'trip_day_id',
        'activity_id',
        'activity_name',
        'category',
        'start_time',
        'duration_minutes',
        'location',
        'guide_name',
        'status',
        'notes',
        'color',
    ];
    protected $casts = [
        'id' => 'integer',
        'trip_day_id' => 'integer',
        'activity_id' => 'integer',
        'duration_minutes' => 'integer',
    ];
    public function trip_day()
    {
        return $this->belongsTo(TripDay::class, 'trip_day_id', 'id');
    }
}