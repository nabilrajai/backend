<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class CashSession extends Model
{
    protected $table = 'cash_sessions';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
        'opened_by',
        'opened_at',
        'opening_balance_mad',
        'closed_by',
        'closed_at',
        'closing_balance_mad',
        'counted_balance_mad',
        'variance_mad',
        'status',
        'notes',
    ];
    protected $casts = [
        'id' => 'integer',
        'opened_by' => 'integer',
        'opened_at' => 'datetime',
        'opening_balance_mad' => 'decimal:2',
        'closed_by' => 'integer',
        'closed_at' => 'datetime',
        'closing_balance_mad' => 'decimal:2',
        'counted_balance_mad' => 'decimal:2',
        'variance_mad' => 'decimal:2',
    ];
    public function user()
    {
        return $this->belongsTo(User::class, 'opened_by', 'id');
    }
}