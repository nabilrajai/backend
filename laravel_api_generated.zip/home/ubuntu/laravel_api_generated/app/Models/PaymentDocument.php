<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class PaymentDocument extends Model
{
    protected $table = 'payment_documents';
    protected $primaryKey = 'id';
    protected $fillable = [
        'public_id',
        'number',
        'type',
        'customer_id',
        'reservation_id',
        'issue_date',
        'due_date',
        'amount_mad',
        'paid_amount_mad',
        'status',
        'payment_method',
        'notes',
        'file_url',
        'created_by',
    ];
    protected $casts = [
        'id' => 'integer',
        'customer_id' => 'integer',
        'reservation_id' => 'integer',
        'issue_date' => 'date',
        'due_date' => 'date',
        'amount_mad' => 'decimal:2',
        'paid_amount_mad' => 'decimal:2',
        'created_by' => 'integer',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];
    public function customer()
    {
        return $this->belongsTo(Customer::class, 'customer_id', 'id');
    }
}