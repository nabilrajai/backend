<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class BusDeparture extends Model
{
    protected $table = 'bus_departures';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
        'bus_id',
        'departure_code',
        'trip_name',
        'route_trajet',
        'start_date',
        'end_date',
        'driver_name',
        'driver_phone',
        'status',
        'notes',
    ];
    protected $casts = [
        'id' => 'integer',
        'bus_id' => 'integer',
        'start_date' => 'date',
        'end_date' => 'date',
        'created_at' => 'datetime',
    ];
}