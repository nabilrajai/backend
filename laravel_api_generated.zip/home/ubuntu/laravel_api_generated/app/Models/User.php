<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class User extends Model
{
    protected $table = 'users';
    protected $primaryKey = 'id';
    use SoftDeletes;
    protected $fillable = [
        'public_id',
        'name',
        'email',
        'phone',
        'password_hash',
        'status',
        'last_signed_in_at',
    ];
    protected $casts = [
        'id' => 'integer',
        'last_signed_in_at' => 'datetime',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
        'deleted_at' => 'datetime',
    ];
}