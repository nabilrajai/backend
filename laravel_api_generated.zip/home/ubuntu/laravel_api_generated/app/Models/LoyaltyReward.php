<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class LoyaltyReward extends Model
{
    protected $table = 'loyalty_rewards';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
        'public_id',
        'name',
        'category',
        'points_cost',
        'description',
        'claimed_count',
        'stock',
        'value_mad',
        'active',
        'created_by',
    ];
    protected $casts = [
        'id' => 'integer',
        'points_cost' => 'integer',
        'claimed_count' => 'integer',
        'stock' => 'integer',
        'value_mad' => 'decimal:2',
        'active' => 'boolean',
        'created_by' => 'integer',
        'created_at' => 'datetime',
    ];
    public function user()
    {
        return $this->belongsTo(User::class, 'created_by', 'id');
    }
}