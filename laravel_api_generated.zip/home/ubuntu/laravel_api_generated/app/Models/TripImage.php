<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class TripImage extends Model
{
    protected $table = 'trip_images';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
        'trip_id',
        'url',
        'name',
        'is_cover',
        'sort_order',
    ];
    protected $casts = [
        'id' => 'integer',
        'trip_id' => 'integer',
        'is_cover' => 'boolean',
        'sort_order' => 'integer',
        'created_at' => 'datetime',
    ];
    public function trip()
    {
        return $this->belongsTo(Trip::class, 'trip_id', 'id');
    }
}