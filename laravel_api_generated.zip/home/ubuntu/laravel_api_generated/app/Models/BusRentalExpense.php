<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BusRentalExpense extends Model
{
    public $timestamps = false;
    protected $table = 'bus_rental_expenses';
    protected $fillable = ['public_id', 'bus_rental_id', 'category', 'title', 'amount_mad', 'expense_date', 'supplier', 'notes'];
    protected $casts = ['amount_mad' => 'decimal:2', 'expense_date' => 'date', 'created_at' => 'datetime'];

    public function rental()
    {
        return $this->belongsTo(BusRental::class, 'bus_rental_id');
    }
}
