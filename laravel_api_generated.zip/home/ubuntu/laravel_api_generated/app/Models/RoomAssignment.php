<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class RoomAssignment extends Model
{
    protected $table = 'room_assignments';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
        'departure_id',
        'reservation_id',
        'accommodation_id',
        'room_number',
        'room_type',
        'hotel_name',
        'occupants',
        'notes',
    ];
    protected $casts = [
        'id' => 'integer',
        'departure_id' => 'integer',
        'reservation_id' => 'integer',
        'accommodation_id' => 'integer',
        'occupants' => 'array',
    ];
    public function departure()
    {
        return $this->belongsTo(Departure::class, 'departure_id', 'id');
    }
}