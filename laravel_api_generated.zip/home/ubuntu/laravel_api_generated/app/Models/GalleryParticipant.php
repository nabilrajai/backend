<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class GalleryParticipant extends Model
{
    protected $table = 'gallery_participants';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
        'gallery_id',
        'customer_id',
        'traveler_id',
        'email',
        'confirmed',
    ];
    protected $casts = [
        'id' => 'integer',
        'gallery_id' => 'integer',
        'customer_id' => 'integer',
        'traveler_id' => 'integer',
        'confirmed' => 'boolean',
    ];
    public function gallery()
    {
        return $this->belongsTo(Gallery::class, 'gallery_id', 'id');
    }
}