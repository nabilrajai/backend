<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class TripDay extends Model
{
    protected $table = 'trip_days';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
        'trip_id',
        'day_number',
        'title',
        'description',
        'program_day_html',
        'meals_included',
        'accommodation_info',
        'distance_km',
    ];
    protected $casts = [
        'id' => 'integer',
        'trip_id' => 'integer',
        'day_number' => 'integer',
        'distance_km' => 'integer',
    ];
    public function trip()
    {
        return $this->belongsTo(Trip::class, 'trip_id', 'id');
    }
}