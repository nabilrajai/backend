<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class Customer extends Model
{
    protected $table = 'customers';
    protected $primaryKey = 'id';
    use SoftDeletes;
    protected $fillable = [
        'public_id',
        'first_name',
        'last_name',
        'email',
        'phone',
        'cin',
        'passport_number',
        'city',
        'country',
        'preferred_language',
        'status',
        'marketing_opt_in',
        'notes',
    ];
    protected $casts = [
        'id' => 'integer',
        'marketing_opt_in' => 'boolean',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
        'deleted_at' => 'datetime',
    ];
}