<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class BusDocument extends Model
{
    protected $table = 'bus_documents';
    protected $primaryKey = 'id';
    protected $fillable = [
        'public_id',
        'bus_id',
        'document_type',
        'title',
        'reference_number',
        'provider',
        'issue_date',
        'expiry_date',
        'cost_mad',
        'file_url',
        'notes',
    ];
    protected $casts = [
        'id' => 'integer',
        'bus_id' => 'integer',
        'issue_date' => 'date',
        'expiry_date' => 'date',
        'cost_mad' => 'decimal:2',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];
}