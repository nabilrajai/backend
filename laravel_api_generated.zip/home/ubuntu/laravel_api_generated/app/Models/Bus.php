<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class Bus extends Model
{
    protected $table = 'buses';
    protected $primaryKey = 'id';
    use SoftDeletes;
    protected $fillable = [
        'public_id',
        'matricule',
        'name',
        'brand',
        'model',
        'bus_type',
        'capacity_seats',
        'year_manufactured',
        'driver_name',
        'driver_phone',
        'owner_type',
        'partner_company',
        'status',
        'mileage_km',
        'amenities',
        'notes',
    ];
    protected $casts = [
        'id' => 'integer',
        'capacity_seats' => 'integer',
        'year_manufactured' => 'integer',
        'mileage_km' => 'integer',
        'amenities' => 'array',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
        'deleted_at' => 'datetime',
    ];
}