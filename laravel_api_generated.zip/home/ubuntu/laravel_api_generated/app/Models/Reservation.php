<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class Reservation extends Model
{
    protected $table = 'reservations';
    protected $primaryKey = 'id';
    use SoftDeletes;
    protected $fillable = [
        'public_id',
        'reference',
        'qr_token',
        'customer_id',
        'trip_id',
        'departure_id',
        'promo_code_id',
        'people_count',
        'group_type',
        'total_mad',
        'discount_mad',
        'paid_mad',
        'status',
        'source',
        'assigned_agent_id',
        'customer_notes',
        'internal_notes',
        'cancelled_at',
    ];
    protected $casts = [
        'id' => 'integer',
        'customer_id' => 'integer',
        'trip_id' => 'integer',
        'departure_id' => 'integer',
        'promo_code_id' => 'integer',
        'people_count' => 'integer',
        'total_mad' => 'decimal:2',
        'discount_mad' => 'decimal:2',
        'paid_mad' => 'decimal:2',
        'assigned_agent_id' => 'integer',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
        'cancelled_at' => 'datetime',
        'deleted_at' => 'datetime',
    ];
    public function customer()
    {
        return $this->belongsTo(Customer::class, 'customer_id', 'id');
    }
}