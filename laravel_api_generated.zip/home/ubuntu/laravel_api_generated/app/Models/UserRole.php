<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class UserRole extends Model
{
    protected $table = 'user_roles';
    // Composite-key table; use controller query methods for key-based operations.
    protected $primaryKey = null;
    public $incrementing = false;
    public $timestamps = false;
    protected $fillable = [
        'user_id',
        'role_id',
    ];
    protected $casts = [
        'user_id' => 'integer',
        'role_id' => 'integer',
    ];
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }
}