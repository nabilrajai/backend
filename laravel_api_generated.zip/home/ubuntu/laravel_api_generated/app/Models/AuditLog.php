<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class AuditLog extends Model
{
    protected $table = 'audit_logs';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
        'actor_user_id',
        'actor_name',
        'action',
        'category',
        'entity_type',
        'entity_id',
        'details',
        'ip_address',
        'user_agent',
    ];
    protected $casts = [
        'id' => 'integer',
        'actor_user_id' => 'integer',
        'details' => 'array',
        'created_at' => 'datetime',
    ];
    public function user()
    {
        return $this->belongsTo(User::class, 'actor_user_id', 'id');
    }
}