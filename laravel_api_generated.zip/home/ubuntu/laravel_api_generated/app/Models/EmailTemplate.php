<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class EmailTemplate extends Model
{
    protected $table = 'email_templates';
    protected $primaryKey = 'id';
    protected $fillable = [
        'public_id',
        'name',
        'subject',
        'category',
        'body_html',
        'body_text',
        'variables',
        'active',
        'updated_by',
    ];
    protected $casts = [
        'id' => 'integer',
        'variables' => 'array',
        'active' => 'boolean',
        'updated_by' => 'integer',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];
    public function user()
    {
        return $this->belongsTo(User::class, 'updated_by', 'id');
    }
}