<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class Vehicle extends Model
{
    protected $table = 'vehicles';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
        'public_id',
        'matricule',
        'model',
        'vehicle_type',
        'capacity_seats',
        'owner_type',
        'partner_name',
        'license_number',
        'insurance_expiry',
        'inspection_expiry',
        'active',
    ];
    protected $casts = [
        'id' => 'integer',
        'capacity_seats' => 'integer',
        'insurance_expiry' => 'date',
        'inspection_expiry' => 'date',
        'active' => 'boolean',
        'created_at' => 'datetime',
    ];
}