<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class PaymentDocumentItem extends Model
{
    protected $table = 'payment_document_items';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
        'document_id',
        'description',
        'quantity',
        'unit_price_mad',
        'total_mad',
    ];
    protected $casts = [
        'id' => 'integer',
        'document_id' => 'integer',
        'quantity' => 'decimal:2',
        'unit_price_mad' => 'decimal:2',
        'total_mad' => 'decimal:2',
    ];
    public function payment_document()
    {
        return $this->belongsTo(PaymentDocument::class, 'document_id', 'id');
    }
}