<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class ActivityImage extends Model
{
    protected $table = 'activity_images';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
        'activity_id',
        'url',
        'name',
        'is_cover',
        'sort_order',
    ];
    protected $casts = [
        'id' => 'integer',
        'activity_id' => 'integer',
        'is_cover' => 'boolean',
        'sort_order' => 'integer',
        'created_at' => 'datetime',
    ];
    public function activity()
    {
        return $this->belongsTo(Activity::class, 'activity_id', 'id');
    }
}