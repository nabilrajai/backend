<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class B2bClient extends Model
{
    use SoftDeletes;

    protected $table = 'b2b_clients';
    protected $fillable = ['public_id', 'company_name', 'contact_name', 'email', 'phone', 'tax_id', 'address', 'city', 'country', 'notes', 'status'];
    protected $casts = ['created_at' => 'datetime', 'updated_at' => 'datetime', 'deleted_at' => 'datetime'];

    public function rentals()
    {
        return $this->hasMany(BusRental::class, 'b2b_client_id');
    }
}
