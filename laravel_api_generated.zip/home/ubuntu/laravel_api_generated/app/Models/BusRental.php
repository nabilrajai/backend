<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class BusRental extends Model
{
    use SoftDeletes;

    protected $table = 'bus_rentals';
    protected $fillable = ['public_id', 'b2b_client_id', 'bus_id', 'contract_reference', 'trip_name', 'pickup_location', 'destination', 'start_at', 'end_at', 'agreed_price_mad', 'status', 'driver_included', 'driver_name', 'driver_phone', 'notes', 'created_by'];
    protected $casts = ['start_at' => 'datetime', 'end_at' => 'datetime', 'agreed_price_mad' => 'decimal:2', 'driver_included' => 'boolean', 'created_at' => 'datetime', 'updated_at' => 'datetime', 'deleted_at' => 'datetime'];

    public function client()
    {
        return $this->belongsTo(B2bClient::class, 'b2b_client_id');
    }

    public function bus()
    {
        return $this->belongsTo(Bus::class, 'bus_id');
    }

    public function expenses()
    {
        return $this->hasMany(BusRentalExpense::class, 'bus_rental_id');
    }
}
