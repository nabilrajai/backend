<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class Payment extends Model
{
    protected $table = 'payments';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
        'public_id',
        'reference',
        'reservation_id',
        'customer_id',
        'departure_id',
        'method',
        'amount_mad',
        'currency',
        'status',
        'payment_type',
        'provider',
        'provider_reference',
        'paid_at',
        'notes',
        'recorded_by',
    ];
    protected $casts = [
        'id' => 'integer',
        'reservation_id' => 'integer',
        'customer_id' => 'integer',
        'departure_id' => 'integer',
        'amount_mad' => 'decimal:2',
        'paid_at' => 'datetime',
        'recorded_by' => 'integer',
        'created_at' => 'datetime',
    ];
    public function reservation()
    {
        return $this->belongsTo(Reservation::class, 'reservation_id', 'id');
    }
}