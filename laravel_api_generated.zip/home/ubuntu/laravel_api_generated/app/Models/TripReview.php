<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class TripReview extends Model
{
    protected $table = 'trip_reviews';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
        'trip_id',
        'customer_id',
        'author_name',
        'rating',
        'comment',
        'status',
    ];
    protected $casts = [
        'id' => 'integer',
        'trip_id' => 'integer',
        'customer_id' => 'integer',
        'rating' => 'integer',
        'created_at' => 'datetime',
    ];
    public function trip()
    {
        return $this->belongsTo(Trip::class, 'trip_id', 'id');
    }
}