<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class BusExpense extends Model
{
    protected $table = 'bus_expenses';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
        'public_id',
        'bus_id',
        'bus_departure_id',
        'departure_code',
        'category',
        'title',
        'amount_mad',
        'expense_date',
        'supplier',
        'invoice_ref',
        'payment_method',
        'recorded_by',
        'notes',
    ];
    protected $casts = [
        'id' => 'integer',
        'bus_id' => 'integer',
        'bus_departure_id' => 'integer',
        'amount_mad' => 'decimal:2',
        'expense_date' => 'date',
        'created_at' => 'datetime',
    ];
}