<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class Trip extends Model
{
    protected $table = 'trips';
    protected $primaryKey = 'id';
    use SoftDeletes;
    protected $fillable = [
        'public_id',
        'slug',
        'title_fr',
        'title_en',
        'category_id',
        'origin_city_id',
        'destination_id',
        'location_label',
        'short_description',
        'description',
        'program_html',
        'program_summary',
        'itinerary_steps',
        'highlights',
        'inclusions',
        'exclusions',
        'meeting_point',
        'difficulty_level',
        'duration_days',
        'duration_nights',
        'price_mad',
        'capacity',
        'featured',
        'rating',
        'reviews_count',
        'status',
        'visibility',
        'tag',
        'accent',
        'cover_image_url',
        'brochure_pdf_url',
        'created_by',
    ];
    protected $casts = [
        'id' => 'integer',
        'category_id' => 'integer',
        'origin_city_id' => 'integer',
        'destination_id' => 'integer',
        'itinerary_steps' => 'array',
        'highlights' => 'array',
        'inclusions' => 'array',
        'exclusions' => 'array',
        'duration_days' => 'integer',
        'duration_nights' => 'integer',
        'price_mad' => 'decimal:2',
        'capacity' => 'integer',
        'featured' => 'boolean',
        'rating' => 'decimal:2',
        'reviews_count' => 'integer',
        'created_by' => 'integer',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
        'deleted_at' => 'datetime',
    ];
    public function category()
    {
        return $this->belongsTo(Category::class, 'category_id', 'id');
    }
}