<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class LoyaltyMember extends Model
{
    protected $table = 'loyalty_members';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
        'customer_id',
        'tier',
        'balance_points',
        'lifetime_points',
        'total_spent_mad',
        'joined_at',
        'last_activity_at',
    ];
    protected $casts = [
        'id' => 'integer',
        'customer_id' => 'integer',
        'balance_points' => 'integer',
        'lifetime_points' => 'integer',
        'total_spent_mad' => 'decimal:2',
        'joined_at' => 'datetime',
        'last_activity_at' => 'datetime',
    ];
    public function customer()
    {
        return $this->belongsTo(Customer::class, 'customer_id', 'id');
    }
}