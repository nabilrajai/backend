<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class PromoCode extends Model
{
    protected $table = 'promo_codes';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
        'code',
        'discount_type',
        'discount_value',
        'min_spend_mad',
        'max_uses',
        'used_count',
        'valid_from',
        'valid_until',
        'active',
    ];
    protected $casts = [
        'id' => 'integer',
        'discount_value' => 'decimal:2',
        'min_spend_mad' => 'decimal:2',
        'max_uses' => 'integer',
        'used_count' => 'integer',
        'valid_from' => 'datetime',
        'valid_until' => 'datetime',
        'active' => 'boolean',
        'created_at' => 'datetime',
    ];
}