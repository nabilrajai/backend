<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class CashEntry extends Model
{
    protected $table = 'cash_entries';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
        'session_id',
        'reference',
        'type',
        'category',
        'description',
        'amount_mad',
        'occurred_at',
        'cashier_id',
        'trip_id',
        'reservation_id',
        'client_name',
        'justification_reference',
        'notes',
    ];
    protected $casts = [
        'id' => 'integer',
        'session_id' => 'integer',
        'amount_mad' => 'decimal:2',
        'occurred_at' => 'datetime',
        'cashier_id' => 'integer',
        'trip_id' => 'integer',
        'reservation_id' => 'integer',
    ];
    public function cash_session()
    {
        return $this->belongsTo(CashSession::class, 'session_id', 'id');
    }
}