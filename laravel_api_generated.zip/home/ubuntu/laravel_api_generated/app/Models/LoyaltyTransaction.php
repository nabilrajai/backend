<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class LoyaltyTransaction extends Model
{
    protected $table = 'loyalty_transactions';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
        'loyalty_member_id',
        'type',
        'points',
        'reason',
        'balance_after',
        'reservation_id',
        'reward_id',
        'signatory_id',
    ];
    protected $casts = [
        'id' => 'integer',
        'loyalty_member_id' => 'integer',
        'points' => 'integer',
        'balance_after' => 'integer',
        'reservation_id' => 'integer',
        'reward_id' => 'integer',
        'signatory_id' => 'integer',
        'created_at' => 'datetime',
    ];
    public function loyalty_member()
    {
        return $this->belongsTo(LoyaltyMember::class, 'loyalty_member_id', 'id');
    }
}