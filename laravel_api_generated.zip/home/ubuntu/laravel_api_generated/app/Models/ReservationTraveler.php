<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class ReservationTraveler extends Model
{
    protected $table = 'reservation_travelers';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
        'reservation_id',
        'customer_id',
        'full_name',
        'document_type',
        'document_number',
        'qr_token',
        'role',
        'date_of_birth',
        'nationality',
        'phone',
        'email',
        'dietary_notes',
        'accommodation_notes',
    ];
    protected $casts = [
        'id' => 'integer',
        'reservation_id' => 'integer',
        'customer_id' => 'integer',
        'date_of_birth' => 'date',
        'created_at' => 'datetime',
    ];
    public function reservation()
    {
        return $this->belongsTo(Reservation::class, 'reservation_id', 'id');
    }
}