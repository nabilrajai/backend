<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class ContactSubmission extends Model
{
    protected $table = 'contact_submissions';
    protected $primaryKey = 'id';
    protected $fillable = [
        'public_id',
        'name',
        'email',
        'phone',
        'subject',
        'message',
        'status',
        'assigned_to',
        'replied_at',
        'internal_notes',
    ];
    protected $casts = [
        'id' => 'integer',
        'assigned_to' => 'integer',
        'replied_at' => 'datetime',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];
    public function user()
    {
        return $this->belongsTo(User::class, 'assigned_to', 'id');
    }
}