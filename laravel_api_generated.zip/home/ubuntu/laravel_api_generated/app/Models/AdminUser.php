<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class AdminUser extends Model
{
    protected $table = 'admin_users';
    protected $primaryKey = 'user_id';
    public $incrementing = false;
    public $timestamps = false;
    protected $fillable = [
        'user_id',
        'role_code',
        'role_label',
        'initials',
        'last_login_at',
        'assigned_trips_count',
    ];
    protected $casts = [
        'user_id' => 'integer',
        'last_login_at' => 'datetime',
        'assigned_trips_count' => 'integer',
    ];
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }
}