<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class RolePermission extends Model
{
    protected $table = 'role_permissions';
    // Composite-key table; use controller query methods for key-based operations.
    protected $primaryKey = null;
    public $incrementing = false;
    public $timestamps = false;
    protected $fillable = [
        'role_id',
        'permission_id',
    ];
    protected $casts = [
        'role_id' => 'integer',
        'permission_id' => 'integer',
    ];
    public function role()
    {
        return $this->belongsTo(Role::class, 'role_id', 'id');
    }
}