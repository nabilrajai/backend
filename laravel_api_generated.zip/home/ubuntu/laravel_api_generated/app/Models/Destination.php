<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class Destination extends Model
{
    protected $table = 'destinations';
    protected $primaryKey = 'id';
    use SoftDeletes;
    protected $fillable = [
        'public_id',
        'name',
        'region',
        'category_id',
        'best_season',
        'highlight',
        'description',
        'cover_color',
        'status',
        'created_by',
    ];
    protected $casts = [
        'id' => 'integer',
        'category_id' => 'integer',
        'created_by' => 'integer',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
        'deleted_at' => 'datetime',
    ];
    public function category()
    {
        return $this->belongsTo(Category::class, 'category_id', 'id');
    }
}