<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class Setting extends Model
{
    protected $table = 'settings';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
        'setting_key',
        'setting_value',
        'is_secret',
        'updated_by',
    ];
    protected $casts = [
        'id' => 'integer',
        'setting_value' => 'array',
        'is_secret' => 'boolean',
        'updated_by' => 'integer',
        'updated_at' => 'datetime',
    ];
    public function user()
    {
        return $this->belongsTo(User::class, 'updated_by', 'id');
    }
}