<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class Gallery extends Model
{
    protected $table = 'galleries';
    protected $primaryKey = 'id';
    protected $fillable = [
        'public_id',
        'departure_id',
        'access',
        'published',
        'cover_url',
        'private_share_token',
        'download_count',
        'created_by',
    ];
    protected $casts = [
        'id' => 'integer',
        'departure_id' => 'integer',
        'published' => 'boolean',
        'download_count' => 'integer',
        'created_by' => 'integer',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];
    public function departure()
    {
        return $this->belongsTo(Departure::class, 'departure_id', 'id');
    }
}