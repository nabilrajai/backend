<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class Accommodation extends Model
{
    protected $table = 'accommodations';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
        'public_id',
        'name',
        'type',
        'city_id',
        'address',
        'contact_phone',
        'contact_email',
        'reception_whatsapp',
        'active',
    ];
    protected $casts = [
        'id' => 'integer',
        'city_id' => 'integer',
        'active' => 'boolean',
        'created_at' => 'datetime',
    ];
    public function city()
    {
        return $this->belongsTo(City::class, 'city_id', 'id');
    }
}