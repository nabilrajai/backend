<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class DepartureActivityOrder extends Model
{
    protected $table = 'departure_activity_orders';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
        'departure_id',
        'reservation_id',
        'activity_id',
        'activity_name',
        'quantity',
        'unit_price_mad',
        'total_price_mad',
        'scheduled_at',
        'payment_status',
        'payment_method',
        'notes',
    ];
    protected $casts = [
        'id' => 'integer',
        'departure_id' => 'integer',
        'reservation_id' => 'integer',
        'activity_id' => 'integer',
        'quantity' => 'integer',
        'unit_price_mad' => 'decimal:2',
        'total_price_mad' => 'decimal:2',
        'scheduled_at' => 'datetime',
    ];
    public function departure()
    {
        return $this->belongsTo(Departure::class, 'departure_id', 'id');
    }
}