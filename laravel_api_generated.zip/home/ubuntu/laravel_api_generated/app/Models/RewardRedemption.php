<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class RewardRedemption extends Model
{
    protected $table = 'reward_redemptions';
    protected $primaryKey = 'id';
    public $timestamps = false;
    protected $fillable = [
        'loyalty_member_id',
        'reward_id',
        'points_spent',
        'status',
        'redeemed_at',
        'fulfilled_at',
        'notes',
    ];
    protected $casts = [
        'id' => 'integer',
        'loyalty_member_id' => 'integer',
        'reward_id' => 'integer',
        'points_spent' => 'integer',
        'redeemed_at' => 'datetime',
        'fulfilled_at' => 'datetime',
    ];
    public function loyalty_member()
    {
        return $this->belongsTo(LoyaltyMember::class, 'loyalty_member_id', 'id');
    }
}