<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\RewardRedemption;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class RewardRedemptionController extends Controller
{
    private string $model = RewardRedemption::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'loyalty_member_id' => 'required|integer',
            'reward_id' => 'required|integer',
            'points_spent' => 'required|integer',
            'status' => 'required|in:requested,approved,fulfilled,cancelled,requested',
            'redeemed_at' => 'required|date',
            'fulfilled_at' => 'nullable|date',
            'notes' => 'nullable|string',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    public function show($id)
    {
        return response()->json($this->model::findOrFail($id));
    }

    public function update(Request $request, $id)
    {
        $record = $this->model::findOrFail($id);
        $validated = $request->validate([
            'loyalty_member_id' => 'sometimes|integer',
            'reward_id' => 'sometimes|integer',
            'points_spent' => 'sometimes|integer',
            'status' => 'sometimes|in:requested,approved,fulfilled,cancelled,requested',
            'redeemed_at' => 'sometimes|date',
            'fulfilled_at' => 'sometimes|date',
            'notes' => 'sometimes|string',
        ]);
        $record->update($validated);
        return response()->json($record->fresh());
    }

    public function destroy($id)
    {
        $record = $this->model::findOrFail($id);
        $record->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

    public function byLoyaltyMember($loyalty_member_id)
    {
        return response()->json($this->model::where('loyalty_member_id', $loyalty_member_id)->paginate(request()->integer('per_page', 15)));
    }

}

