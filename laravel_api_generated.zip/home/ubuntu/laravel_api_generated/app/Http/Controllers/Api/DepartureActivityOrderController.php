<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\DepartureActivityOrder;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class DepartureActivityOrderController extends Controller
{
    private string $model = DepartureActivityOrder::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'departure_id' => 'required|integer',
            'reservation_id' => 'required|integer',
            'activity_id' => 'nullable|integer',
            'activity_name' => 'required|string',
            'quantity' => 'required|integer',
            'unit_price_mad' => 'required|numeric',
            'total_price_mad' => 'required|numeric',
            'scheduled_at' => 'nullable|date',
            'payment_status' => 'required|in:unpaid,paid,pay_on_site,unpaid',
            'payment_method' => 'nullable|string',
            'notes' => 'nullable|string',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    public function show($id)
    {
        return response()->json($this->model::findOrFail($id));
    }

    public function update(Request $request, $id)
    {
        $record = $this->model::findOrFail($id);
        $validated = $request->validate([
            'departure_id' => 'sometimes|integer',
            'reservation_id' => 'sometimes|integer',
            'activity_id' => 'sometimes|integer',
            'activity_name' => 'sometimes|string',
            'quantity' => 'sometimes|integer',
            'unit_price_mad' => 'sometimes|numeric',
            'total_price_mad' => 'sometimes|numeric',
            'scheduled_at' => 'sometimes|date',
            'payment_status' => 'sometimes|in:unpaid,paid,pay_on_site,unpaid',
            'payment_method' => 'sometimes|string',
            'notes' => 'sometimes|string',
        ]);
        $record->update($validated);
        return response()->json($record->fresh());
    }

    public function destroy($id)
    {
        $record = $this->model::findOrFail($id);
        $record->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

    public function byDeparture($departure_id)
    {
        return response()->json($this->model::where('departure_id', $departure_id)->paginate(request()->integer('per_page', 15)));
    }

}

