<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\PaymentDocument;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class PaymentDocumentController extends Controller
{
    private string $model = PaymentDocument::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'public_id' => 'required|string',
            'number' => 'required|string',
            'type' => 'required|in:invoice,deposit_receipt,quote,departure_voucher,contract',
            'customer_id' => 'nullable|integer',
            'reservation_id' => 'nullable|integer',
            'issue_date' => 'required|date',
            'due_date' => 'nullable|date',
            'amount_mad' => 'required|numeric',
            'paid_amount_mad' => 'required|numeric',
            'status' => 'required|in:draft,sent,deposit_received,paid,pending,cancelled,draft',
            'payment_method' => 'nullable|string',
            'notes' => 'nullable|string',
            'file_url' => 'nullable|string',
            'created_by' => 'nullable|integer',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    public function show($id)
    {
        return response()->json($this->model::findOrFail($id));
    }

    public function update(Request $request, $id)
    {
        $record = $this->model::findOrFail($id);
        $validated = $request->validate([
            'public_id' => 'sometimes|string',
            'number' => 'sometimes|string',
            'type' => 'sometimes|in:invoice,deposit_receipt,quote,departure_voucher,contract',
            'customer_id' => 'sometimes|integer',
            'reservation_id' => 'sometimes|integer',
            'issue_date' => 'sometimes|date',
            'due_date' => 'sometimes|date',
            'amount_mad' => 'sometimes|numeric',
            'paid_amount_mad' => 'sometimes|numeric',
            'status' => 'sometimes|in:draft,sent,deposit_received,paid,pending,cancelled,draft',
            'payment_method' => 'sometimes|string',
            'notes' => 'sometimes|string',
            'file_url' => 'sometimes|string',
            'created_by' => 'sometimes|integer',
        ]);
        $record->update($validated);
        return response()->json($record->fresh());
    }

    public function destroy($id)
    {
        $record = $this->model::findOrFail($id);
        $record->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

    public function byCustomer($customer_id)
    {
        return response()->json($this->model::where('customer_id', $customer_id)->paginate(request()->integer('per_page', 15)));
    }

}

