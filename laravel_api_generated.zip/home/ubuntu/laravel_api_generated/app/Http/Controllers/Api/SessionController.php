<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Session;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class SessionController extends Controller
{
    private string $model = Session::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'user_id' => 'required|integer',
            'token_hash' => 'required|string',
            'expires_at' => 'required|date',
            'ip_address' => 'nullable|string',
            'user_agent' => 'nullable|string',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    public function show($id)
    {
        return response()->json($this->model::findOrFail($id));
    }

    public function update(Request $request, $id)
    {
        $record = $this->model::findOrFail($id);
        $validated = $request->validate([
            'user_id' => 'sometimes|integer',
            'token_hash' => 'sometimes|string',
            'expires_at' => 'sometimes|date',
            'ip_address' => 'sometimes|string',
            'user_agent' => 'sometimes|string',
        ]);
        $record->update($validated);
        return response()->json($record->fresh());
    }

    public function destroy($id)
    {
        $record = $this->model::findOrFail($id);
        $record->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

    public function byUser($user_id)
    {
        return response()->json($this->model::where('user_id', $user_id)->paginate(request()->integer('per_page', 15)));
    }

}

