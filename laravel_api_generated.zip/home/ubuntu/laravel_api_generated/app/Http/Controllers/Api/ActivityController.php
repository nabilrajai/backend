<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Activity;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ActivityController extends Controller
{
    private string $model = Activity::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'public_id' => 'required|string',
            'name' => 'required|string',
            'category' => 'required|in:aventure,culture,randonnée,gastronomie,détente,service vip,autre,autre',
            'location' => 'nullable|string',
            'duration_minutes' => 'required|integer',
            'price_mad' => 'required|numeric',
            'description' => 'nullable|string',
            'rating' => 'nullable|numeric',
            'reviews_count' => 'required|integer',
            'inclusions' => 'nullable|array',
            'status' => 'required|in:active,draft,archived,draft',
            'created_by' => 'nullable|integer',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    public function show($id)
    {
        return response()->json($this->model::findOrFail($id));
    }

    public function update(Request $request, $id)
    {
        $record = $this->model::findOrFail($id);
        $validated = $request->validate([
            'public_id' => 'sometimes|string',
            'name' => 'sometimes|string',
            'category' => 'sometimes|in:aventure,culture,randonnée,gastronomie,détente,service vip,autre,autre',
            'location' => 'sometimes|string',
            'duration_minutes' => 'sometimes|integer',
            'price_mad' => 'sometimes|numeric',
            'description' => 'sometimes|string',
            'rating' => 'sometimes|numeric',
            'reviews_count' => 'sometimes|integer',
            'inclusions' => 'sometimes|array',
            'status' => 'sometimes|in:active,draft,archived,draft',
            'created_by' => 'sometimes|integer',
        ]);
        $record->update($validated);
        return response()->json($record->fresh());
    }

    public function destroy($id)
    {
        $record = $this->model::findOrFail($id);
        $record->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

    public function byUser($created_by)
    {
        return response()->json($this->model::where('created_by', $created_by)->paginate(request()->integer('per_page', 15)));
    }

}

