<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class SettingController extends Controller
{
    private string $model = Setting::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'setting_key' => 'required|string',
            'setting_value' => 'required|array',
            'is_secret' => 'required|boolean',
            'updated_by' => 'nullable|integer',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    public function show($id)
    {
        return response()->json($this->model::findOrFail($id));
    }

    public function update(Request $request, $id)
    {
        $record = $this->model::findOrFail($id);
        $validated = $request->validate([
            'setting_key' => 'sometimes|string',
            'setting_value' => 'sometimes|array',
            'is_secret' => 'sometimes|boolean',
            'updated_by' => 'sometimes|integer',
        ]);
        $record->update($validated);
        return response()->json($record->fresh());
    }

    public function destroy($id)
    {
        $record = $this->model::findOrFail($id);
        $record->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

    public function byUser($updated_by)
    {
        return response()->json($this->model::where('updated_by', $updated_by)->paginate(request()->integer('per_page', 15)));
    }

}

