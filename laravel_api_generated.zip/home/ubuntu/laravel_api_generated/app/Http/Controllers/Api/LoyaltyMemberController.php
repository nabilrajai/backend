<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\LoyaltyMember;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class LoyaltyMemberController extends Controller
{
    private string $model = LoyaltyMember::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'customer_id' => 'required|integer',
            'tier' => 'required|in:bronze,argent,or,atlas,bronze',
            'balance_points' => 'required|integer',
            'lifetime_points' => 'required|integer',
            'total_spent_mad' => 'required|numeric',
            'joined_at' => 'required|date',
            'last_activity_at' => 'nullable|date',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    public function show($id)
    {
        return response()->json($this->model::findOrFail($id));
    }

    public function update(Request $request, $id)
    {
        $record = $this->model::findOrFail($id);
        $validated = $request->validate([
            'customer_id' => 'sometimes|integer',
            'tier' => 'sometimes|in:bronze,argent,or,atlas,bronze',
            'balance_points' => 'sometimes|integer',
            'lifetime_points' => 'sometimes|integer',
            'total_spent_mad' => 'sometimes|numeric',
            'joined_at' => 'sometimes|date',
            'last_activity_at' => 'sometimes|date',
        ]);
        $record->update($validated);
        return response()->json($record->fresh());
    }

    public function destroy($id)
    {
        $record = $this->model::findOrFail($id);
        $record->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

    public function byCustomer($customer_id)
    {
        return response()->json($this->model::where('customer_id', $customer_id)->paginate(request()->integer('per_page', 15)));
    }

}

