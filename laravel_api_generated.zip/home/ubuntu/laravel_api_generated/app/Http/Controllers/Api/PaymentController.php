<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Payment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class PaymentController extends Controller
{
    private string $model = Payment::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'public_id' => 'required|string',
            'reference' => 'required|string',
            'reservation_id' => 'nullable|integer',
            'customer_id' => 'nullable|integer',
            'departure_id' => 'nullable|integer',
            'method' => 'required|in:cash,bank_transfer,card,online,cheque,other,other',
            'amount_mad' => 'required|numeric',
            'currency' => 'required|string',
            'status' => 'required|in:pending,succeeded,failed,refunded,to_reconcile,succeeded',
            'payment_type' => 'nullable|string',
            'provider' => 'nullable|string',
            'provider_reference' => 'nullable|string',
            'paid_at' => 'required|date',
            'notes' => 'nullable|string',
            'recorded_by' => 'nullable|integer',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    public function show($id)
    {
        return response()->json($this->model::findOrFail($id));
    }

    public function update(Request $request, $id)
    {
        $record = $this->model::findOrFail($id);
        $validated = $request->validate([
            'public_id' => 'sometimes|string',
            'reference' => 'sometimes|string',
            'reservation_id' => 'sometimes|integer',
            'customer_id' => 'sometimes|integer',
            'departure_id' => 'sometimes|integer',
            'method' => 'sometimes|in:cash,bank_transfer,card,online,cheque,other,other',
            'amount_mad' => 'sometimes|numeric',
            'currency' => 'sometimes|string',
            'status' => 'sometimes|in:pending,succeeded,failed,refunded,to_reconcile,succeeded',
            'payment_type' => 'sometimes|string',
            'provider' => 'sometimes|string',
            'provider_reference' => 'sometimes|string',
            'paid_at' => 'sometimes|date',
            'notes' => 'sometimes|string',
            'recorded_by' => 'sometimes|integer',
        ]);
        $record->update($validated);
        return response()->json($record->fresh());
    }

    public function destroy($id)
    {
        $record = $this->model::findOrFail($id);
        $record->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

    public function byReservation($reservation_id)
    {
        return response()->json($this->model::where('reservation_id', $reservation_id)->paginate(request()->integer('per_page', 15)));
    }

}

