<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class AuditLogController extends Controller
{
    private string $model = AuditLog::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'actor_user_id' => 'nullable|integer',
            'actor_name' => 'nullable|string',
            'action' => 'required|string',
            'category' => 'nullable|string',
            'entity_type' => 'nullable|string',
            'entity_id' => 'nullable|string',
            'details' => 'nullable|array',
            'ip_address' => 'nullable|string',
            'user_agent' => 'nullable|string',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    public function show($id)
    {
        return response()->json($this->model::findOrFail($id));
    }

    public function update(Request $request, $id)
    {
        $record = $this->model::findOrFail($id);
        $validated = $request->validate([
            'actor_user_id' => 'sometimes|integer',
            'actor_name' => 'sometimes|string',
            'action' => 'sometimes|string',
            'category' => 'sometimes|string',
            'entity_type' => 'sometimes|string',
            'entity_id' => 'sometimes|string',
            'details' => 'sometimes|array',
            'ip_address' => 'sometimes|string',
            'user_agent' => 'sometimes|string',
        ]);
        $record->update($validated);
        return response()->json($record->fresh());
    }

    public function destroy($id)
    {
        $record = $this->model::findOrFail($id);
        $record->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

    public function byUser($actor_user_id)
    {
        return response()->json($this->model::where('actor_user_id', $actor_user_id)->paginate(request()->integer('per_page', 15)));
    }

}

