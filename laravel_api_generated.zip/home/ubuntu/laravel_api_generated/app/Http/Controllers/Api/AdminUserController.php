<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\AdminUser;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class AdminUserController extends Controller
{
    private string $model = AdminUser::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'user_id' => 'required|integer',
            'role_code' => 'required|in:super_admin,admin,staff,finance,content_manager,operations,guide,staff',
            'role_label' => 'nullable|string',
            'initials' => 'nullable|string',
            'last_login_at' => 'nullable|date',
            'assigned_trips_count' => 'required|integer',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    public function show($user_id)
    {
        return response()->json($this->model::findOrFail($user_id));
    }

    public function update(Request $request, $user_id)
    {
        $record = $this->model::findOrFail($user_id);
        $validated = $request->validate([
            'user_id' => 'sometimes|integer',
            'role_code' => 'sometimes|in:super_admin,admin,staff,finance,content_manager,operations,guide,staff',
            'role_label' => 'sometimes|string',
            'initials' => 'sometimes|string',
            'last_login_at' => 'sometimes|date',
            'assigned_trips_count' => 'sometimes|integer',
        ]);
        $record->update($validated);
        return response()->json($record->fresh());
    }

    public function destroy($user_id)
    {
        $record = $this->model::findOrFail($user_id);
        $record->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

    public function byUser($user_id)
    {
        return response()->json($this->model::where('user_id', $user_id)->paginate(request()->integer('per_page', 15)));
    }

}

