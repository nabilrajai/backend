<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Reservation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ReservationController extends Controller
{
    private string $model = Reservation::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'public_id' => 'required|string',
            'reference' => 'required|string',
            'qr_token' => 'nullable|string',
            'customer_id' => 'required|integer',
            'trip_id' => 'required|integer',
            'departure_id' => 'nullable|integer',
            'promo_code_id' => 'nullable|integer',
            'people_count' => 'required|integer',
            'group_type' => 'nullable|string',
            'total_mad' => 'required|numeric',
            'discount_mad' => 'required|numeric',
            'paid_mad' => 'required|numeric',
            'status' => 'required|in:draft,pending,awaiting_payment,partially_paid,confirmed,cancelled,completed,draft',
            'source' => 'required|in:website,admin,phone,whatsapp,partner,import,website',
            'assigned_agent_id' => 'nullable|integer',
            'customer_notes' => 'nullable|string',
            'internal_notes' => 'nullable|string',
            'cancelled_at' => 'nullable|date',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    public function show($id)
    {
        return response()->json($this->model::findOrFail($id));
    }

    public function update(Request $request, $id)
    {
        $record = $this->model::findOrFail($id);
        $validated = $request->validate([
            'public_id' => 'sometimes|string',
            'reference' => 'sometimes|string',
            'qr_token' => 'sometimes|string',
            'customer_id' => 'sometimes|integer',
            'trip_id' => 'sometimes|integer',
            'departure_id' => 'sometimes|integer',
            'promo_code_id' => 'sometimes|integer',
            'people_count' => 'sometimes|integer',
            'group_type' => 'sometimes|string',
            'total_mad' => 'sometimes|numeric',
            'discount_mad' => 'sometimes|numeric',
            'paid_mad' => 'sometimes|numeric',
            'status' => 'sometimes|in:draft,pending,awaiting_payment,partially_paid,confirmed,cancelled,completed,draft',
            'source' => 'sometimes|in:website,admin,phone,whatsapp,partner,import,website',
            'assigned_agent_id' => 'sometimes|integer',
            'customer_notes' => 'sometimes|string',
            'internal_notes' => 'sometimes|string',
            'cancelled_at' => 'sometimes|date',
        ]);
        $record->update($validated);
        return response()->json($record->fresh());
    }

    public function destroy($id)
    {
        $record = $this->model::findOrFail($id);
        $record->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

    public function byCustomer($customer_id)
    {
        return response()->json($this->model::where('customer_id', $customer_id)->paginate(request()->integer('per_page', 15)));
    }

}

