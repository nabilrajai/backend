<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ReservationTimeline;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ReservationTimelineController extends Controller
{
    private string $model = ReservationTimeline::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'reservation_id' => 'required|integer',
            'category' => 'required|in:booking_creation,status_update,payment_log,traveler_update,communication_log,note_internal',
            'title' => 'required|string',
            'description' => 'nullable|string',
            'details' => 'nullable|array',
            'author_user_id' => 'nullable|integer',
            'is_system' => 'required|boolean',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    public function show($id)
    {
        return response()->json($this->model::findOrFail($id));
    }

    public function update(Request $request, $id)
    {
        $record = $this->model::findOrFail($id);
        $validated = $request->validate([
            'reservation_id' => 'sometimes|integer',
            'category' => 'sometimes|in:booking_creation,status_update,payment_log,traveler_update,communication_log,note_internal',
            'title' => 'sometimes|string',
            'description' => 'sometimes|string',
            'details' => 'sometimes|array',
            'author_user_id' => 'sometimes|integer',
            'is_system' => 'sometimes|boolean',
        ]);
        $record->update($validated);
        return response()->json($record->fresh());
    }

    public function destroy($id)
    {
        $record = $this->model::findOrFail($id);
        $record->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

    public function byReservation($reservation_id)
    {
        return response()->json($this->model::where('reservation_id', $reservation_id)->paginate(request()->integer('per_page', 15)));
    }

}

