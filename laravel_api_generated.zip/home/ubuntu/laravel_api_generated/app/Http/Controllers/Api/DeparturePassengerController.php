<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\DeparturePassenger;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class DeparturePassengerController extends Controller
{
    private string $model = DeparturePassenger::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'departure_id' => 'required|integer',
            'reservation_id' => 'required|integer',
            'passenger_count' => 'required|integer',
            'phone' => 'nullable|string',
            'paid' => 'required|boolean',
            'notes' => 'nullable|string',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    public function show($id)
    {
        return response()->json($this->model::findOrFail($id));
    }

    public function update(Request $request, $id)
    {
        $record = $this->model::findOrFail($id);
        $validated = $request->validate([
            'departure_id' => 'sometimes|integer',
            'reservation_id' => 'sometimes|integer',
            'passenger_count' => 'sometimes|integer',
            'phone' => 'sometimes|string',
            'paid' => 'sometimes|boolean',
            'notes' => 'sometimes|string',
        ]);
        $record->update($validated);
        return response()->json($record->fresh());
    }

    public function destroy($id)
    {
        $record = $this->model::findOrFail($id);
        $record->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

    public function byDeparture($departure_id)
    {
        return response()->json($this->model::where('departure_id', $departure_id)->paginate(request()->integer('per_page', 15)));
    }

}

