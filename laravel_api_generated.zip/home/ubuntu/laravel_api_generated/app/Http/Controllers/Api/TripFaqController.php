<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\TripFaq;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class TripFaqController extends Controller
{
    private string $model = TripFaq::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'trip_id' => 'required|integer',
            'question' => 'required|string',
            'answer' => 'required|string',
            'sort_order' => 'required|integer',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    public function show($id)
    {
        return response()->json($this->model::findOrFail($id));
    }

    public function update(Request $request, $id)
    {
        $record = $this->model::findOrFail($id);
        $validated = $request->validate([
            'trip_id' => 'sometimes|integer',
            'question' => 'sometimes|string',
            'answer' => 'sometimes|string',
            'sort_order' => 'sometimes|integer',
        ]);
        $record->update($validated);
        return response()->json($record->fresh());
    }

    public function destroy($id)
    {
        $record = $this->model::findOrFail($id);
        $record->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

    public function byTrip($trip_id)
    {
        return response()->json($this->model::where('trip_id', $trip_id)->paginate(request()->integer('per_page', 15)));
    }

}

