<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\TripReview;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class TripReviewController extends Controller
{
    private string $model = TripReview::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'trip_id' => 'required|integer',
            'customer_id' => 'nullable|integer',
            'author_name' => 'required|string',
            'rating' => 'required',
            'comment' => 'nullable|string',
            'status' => 'required|in:pending,approved,rejected,approved',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    public function show($id)
    {
        return response()->json($this->model::findOrFail($id));
    }

    public function update(Request $request, $id)
    {
        $record = $this->model::findOrFail($id);
        $validated = $request->validate([
            'trip_id' => 'sometimes|integer',
            'customer_id' => 'sometimes|integer',
            'author_name' => 'sometimes|string',
            'rating' => 'sometimes',
            'comment' => 'sometimes|string',
            'status' => 'sometimes|in:pending,approved,rejected,approved',
        ]);
        $record->update($validated);
        return response()->json($record->fresh());
    }

    public function destroy($id)
    {
        $record = $this->model::findOrFail($id);
        $record->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

    public function byTrip($trip_id)
    {
        return response()->json($this->model::where('trip_id', $trip_id)->paginate(request()->integer('per_page', 15)));
    }

}

