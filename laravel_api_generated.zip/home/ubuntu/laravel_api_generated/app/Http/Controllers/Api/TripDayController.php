<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\TripDay;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class TripDayController extends Controller
{
    private string $model = TripDay::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'trip_id' => 'required|integer',
            'day_number' => 'required',
            'title' => 'nullable|string',
            'description' => 'nullable|string',
            'program_day_html' => 'nullable|string',
            'meals_included' => 'nullable|string',
            'accommodation_info' => 'nullable|string',
            'distance_km' => 'nullable|integer',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    public function show($id)
    {
        return response()->json($this->model::findOrFail($id));
    }

    public function update(Request $request, $id)
    {
        $record = $this->model::findOrFail($id);
        $validated = $request->validate([
            'trip_id' => 'sometimes|integer',
            'day_number' => 'sometimes',
            'title' => 'sometimes|string',
            'description' => 'sometimes|string',
            'program_day_html' => 'sometimes|string',
            'meals_included' => 'sometimes|string',
            'accommodation_info' => 'sometimes|string',
            'distance_km' => 'sometimes|integer',
        ]);
        $record->update($validated);
        return response()->json($record->fresh());
    }

    public function destroy($id)
    {
        $record = $this->model::findOrFail($id);
        $record->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

    public function byTrip($trip_id)
    {
        return response()->json($this->model::where('trip_id', $trip_id)->paginate(request()->integer('per_page', 15)));
    }

}

