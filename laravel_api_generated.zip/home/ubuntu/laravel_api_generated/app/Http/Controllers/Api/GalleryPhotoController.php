<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\GalleryPhoto;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class GalleryPhotoController extends Controller
{
    private string $model = GalleryPhoto::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'gallery_id' => 'required|integer',
            'url' => 'required|string',
            'caption' => 'nullable|string',
            'uploaded_by' => 'nullable|integer',
            'is_cover' => 'required|boolean',
            'sort_order' => 'required|integer',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    public function show($id)
    {
        return response()->json($this->model::findOrFail($id));
    }

    public function update(Request $request, $id)
    {
        $record = $this->model::findOrFail($id);
        $validated = $request->validate([
            'gallery_id' => 'sometimes|integer',
            'url' => 'sometimes|string',
            'caption' => 'sometimes|string',
            'uploaded_by' => 'sometimes|integer',
            'is_cover' => 'sometimes|boolean',
            'sort_order' => 'sometimes|integer',
        ]);
        $record->update($validated);
        return response()->json($record->fresh());
    }

    public function destroy($id)
    {
        $record = $this->model::findOrFail($id);
        $record->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

    public function byGallery($gallery_id)
    {
        return response()->json($this->model::where('gallery_id', $gallery_id)->paginate(request()->integer('per_page', 15)));
    }

}

