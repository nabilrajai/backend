<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\BusExpense;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class BusExpenseController extends Controller
{
    private string $model = BusExpense::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'public_id' => 'required|string',
            'bus_id' => 'required|integer',
            'bus_departure_id' => 'nullable|integer',
            'departure_code' => 'nullable|string',
            'category' => 'required|in:carburant,peage,frais_chauffeur,entretien_reparation,lavage,parking,assurance_doc,autre,carburant',
            'title' => 'required|string',
            'amount_mad' => 'required|numeric',
            'expense_date' => 'required|date',
            'supplier' => 'nullable|string',
            'invoice_ref' => 'nullable|string',
            'payment_method' => 'required|in:especes_caisse,virement,carte,cheque,especes_caisse',
            'recorded_by' => 'nullable|string',
            'notes' => 'nullable|string',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    public function show($id)
    {
        return response()->json($this->model::findOrFail($id));
    }

    public function update(Request $request, $id)
    {
        $record = $this->model::findOrFail($id);
        $validated = $request->validate([
            'public_id' => 'sometimes|string',
            'bus_id' => 'sometimes|integer',
            'bus_departure_id' => 'sometimes|integer',
            'departure_code' => 'sometimes|string',
            'category' => 'sometimes|in:carburant,peage,frais_chauffeur,entretien_reparation,lavage,parking,assurance_doc,autre,carburant',
            'title' => 'sometimes|string',
            'amount_mad' => 'sometimes|numeric',
            'expense_date' => 'sometimes|date',
            'supplier' => 'sometimes|string',
            'invoice_ref' => 'sometimes|string',
            'payment_method' => 'sometimes|in:especes_caisse,virement,carte,cheque,especes_caisse',
            'recorded_by' => 'sometimes|string',
            'notes' => 'sometimes|string',
        ]);
        $record->update($validated);
        return response()->json($record->fresh());
    }

    public function destroy($id)
    {
        $record = $this->model::findOrFail($id);
        $record->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

}

