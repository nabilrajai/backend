<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\UserRole;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class UserRoleController extends Controller
{
    private string $model = UserRole::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'user_id' => 'required|integer',
            'role_id' => 'required|integer',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    private function keyQuery(Request $request)
    {
        return $this->model::query()->where(['user_id' => $request->input('user_id'), 'role_id' => $request->input('role_id')]);
    }

    public function show(Request $request)
    {
        return response()->json($this->keyQuery($request)->firstOrFail());
    }

    public function update(Request $request)
    {
        $record = $this->keyQuery($request)->firstOrFail();
        $validated = $request->validate([
            'user_id' => 'sometimes|integer',
            'role_id' => 'sometimes|integer',
        ]);
        $record->forceFill($validated)->save();
        return response()->json($record->fresh());
    }

    public function destroy(Request $request)
    {
        $this->keyQuery($request)->firstOrFail()->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

    public function byUser($user_id)
    {
        return response()->json($this->model::where('user_id', $user_id)->paginate(request()->integer('per_page', 15)));
    }

}

