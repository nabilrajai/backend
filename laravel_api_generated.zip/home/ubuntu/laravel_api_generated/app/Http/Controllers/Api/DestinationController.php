<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Destination;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class DestinationController extends Controller
{
    private string $model = Destination::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'public_id' => 'required|string',
            'name' => 'required|string',
            'region' => 'nullable|string',
            'category_id' => 'nullable|integer',
            'best_season' => 'nullable|string',
            'highlight' => 'nullable|string',
            'description' => 'nullable|string',
            'cover_color' => 'nullable|string',
            'status' => 'required|in:draft,published,archived,draft',
            'created_by' => 'nullable|integer',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    public function show($id)
    {
        return response()->json($this->model::findOrFail($id));
    }

    public function update(Request $request, $id)
    {
        $record = $this->model::findOrFail($id);
        $validated = $request->validate([
            'public_id' => 'sometimes|string',
            'name' => 'sometimes|string',
            'region' => 'sometimes|string',
            'category_id' => 'sometimes|integer',
            'best_season' => 'sometimes|string',
            'highlight' => 'sometimes|string',
            'description' => 'sometimes|string',
            'cover_color' => 'sometimes|string',
            'status' => 'sometimes|in:draft,published,archived,draft',
            'created_by' => 'sometimes|integer',
        ]);
        $record->update($validated);
        return response()->json($record->fresh());
    }

    public function destroy($id)
    {
        $record = $this->model::findOrFail($id);
        $record->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

    public function byCategory($category_id)
    {
        return response()->json($this->model::where('category_id', $category_id)->paginate(request()->integer('per_page', 15)));
    }

}

