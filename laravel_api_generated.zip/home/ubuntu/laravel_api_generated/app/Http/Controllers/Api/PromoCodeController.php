<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\PromoCode;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class PromoCodeController extends Controller
{
    private string $model = PromoCode::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'code' => 'required|string',
            'discount_type' => 'required|in:percentage,fixed_mad,percentage',
            'discount_value' => 'required|numeric',
            'min_spend_mad' => 'required|numeric',
            'max_uses' => 'nullable|integer',
            'used_count' => 'required|integer',
            'valid_from' => 'required|date',
            'valid_until' => 'required|date',
            'active' => 'required|boolean',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    public function show($id)
    {
        return response()->json($this->model::findOrFail($id));
    }

    public function update(Request $request, $id)
    {
        $record = $this->model::findOrFail($id);
        $validated = $request->validate([
            'code' => 'sometimes|string',
            'discount_type' => 'sometimes|in:percentage,fixed_mad,percentage',
            'discount_value' => 'sometimes|numeric',
            'min_spend_mad' => 'sometimes|numeric',
            'max_uses' => 'sometimes|integer',
            'used_count' => 'sometimes|integer',
            'valid_from' => 'sometimes|date',
            'valid_until' => 'sometimes|date',
            'active' => 'sometimes|boolean',
        ]);
        $record->update($validated);
        return response()->json($record->fresh());
    }

    public function destroy($id)
    {
        $record = $this->model::findOrFail($id);
        $record->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

}

