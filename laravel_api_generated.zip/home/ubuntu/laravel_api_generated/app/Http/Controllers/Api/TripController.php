<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Trip;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class TripController extends Controller
{
    private string $model = Trip::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'public_id' => 'required|string',
            'slug' => 'required|string',
            'title_fr' => 'required|string',
            'title_en' => 'nullable|string',
            'category_id' => 'nullable|integer',
            'origin_city_id' => 'nullable|integer',
            'destination_id' => 'nullable|integer',
            'location_label' => 'nullable|string',
            'short_description' => 'nullable|string',
            'description' => 'nullable|string',
            'program_html' => 'nullable|string',
            'program_summary' => 'nullable|string',
            'itinerary_steps' => 'nullable|array',
            'highlights' => 'nullable|array',
            'inclusions' => 'nullable|array',
            'exclusions' => 'nullable|array',
            'meeting_point' => 'nullable|string',
            'difficulty_level' => 'required|in:facile,modéré,soutenu,expert,modéré',
            'duration_days' => 'required',
            'duration_nights' => 'required',
            'price_mad' => 'required|numeric',
            'capacity' => 'required|integer',
            'featured' => 'required|boolean',
            'rating' => 'required|numeric',
            'reviews_count' => 'required|integer',
            'status' => 'required|in:draft,published,archived,draft',
            'visibility' => 'required|in:public,private,public',
            'tag' => 'nullable|string',
            'accent' => 'nullable|string',
            'cover_image_url' => 'nullable|string',
            'brochure_pdf_url' => 'nullable|string',
            'created_by' => 'nullable|integer',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    public function show($id)
    {
        return response()->json($this->model::findOrFail($id));
    }

    public function update(Request $request, $id)
    {
        $record = $this->model::findOrFail($id);
        $validated = $request->validate([
            'public_id' => 'sometimes|string',
            'slug' => 'sometimes|string',
            'title_fr' => 'sometimes|string',
            'title_en' => 'sometimes|string',
            'category_id' => 'sometimes|integer',
            'origin_city_id' => 'sometimes|integer',
            'destination_id' => 'sometimes|integer',
            'location_label' => 'sometimes|string',
            'short_description' => 'sometimes|string',
            'description' => 'sometimes|string',
            'program_html' => 'sometimes|string',
            'program_summary' => 'sometimes|string',
            'itinerary_steps' => 'sometimes|array',
            'highlights' => 'sometimes|array',
            'inclusions' => 'sometimes|array',
            'exclusions' => 'sometimes|array',
            'meeting_point' => 'sometimes|string',
            'difficulty_level' => 'sometimes|in:facile,modéré,soutenu,expert,modéré',
            'duration_days' => 'sometimes',
            'duration_nights' => 'sometimes',
            'price_mad' => 'sometimes|numeric',
            'capacity' => 'sometimes|integer',
            'featured' => 'sometimes|boolean',
            'rating' => 'sometimes|numeric',
            'reviews_count' => 'sometimes|integer',
            'status' => 'sometimes|in:draft,published,archived,draft',
            'visibility' => 'sometimes|in:public,private,public',
            'tag' => 'sometimes|string',
            'accent' => 'sometimes|string',
            'cover_image_url' => 'sometimes|string',
            'brochure_pdf_url' => 'sometimes|string',
            'created_by' => 'sometimes|integer',
        ]);
        $record->update($validated);
        return response()->json($record->fresh());
    }

    public function destroy($id)
    {
        $record = $this->model::findOrFail($id);
        $record->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

    public function byCategory($category_id)
    {
        return response()->json($this->model::where('category_id', $category_id)->paginate(request()->integer('per_page', 15)));
    }

}

