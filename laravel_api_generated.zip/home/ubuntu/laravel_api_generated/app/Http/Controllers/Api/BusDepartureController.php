<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\BusDeparture;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class BusDepartureController extends Controller
{
    private string $model = BusDeparture::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'bus_id' => 'required|integer',
            'departure_code' => 'required|string',
            'trip_name' => 'required|string',
            'route_trajet' => 'required|string',
            'start_date' => 'required|date',
            'end_date' => 'required|date',
            'driver_name' => 'nullable|string',
            'driver_phone' => 'nullable|string',
            'status' => 'required|in:scheduled,in_progress,completed,cancelled,scheduled',
            'notes' => 'nullable|string',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    public function show($id)
    {
        return response()->json($this->model::findOrFail($id));
    }

    public function update(Request $request, $id)
    {
        $record = $this->model::findOrFail($id);
        $validated = $request->validate([
            'bus_id' => 'sometimes|integer',
            'departure_code' => 'sometimes|string',
            'trip_name' => 'sometimes|string',
            'route_trajet' => 'sometimes|string',
            'start_date' => 'sometimes|date',
            'end_date' => 'sometimes|date',
            'driver_name' => 'sometimes|string',
            'driver_phone' => 'sometimes|string',
            'status' => 'sometimes|in:scheduled,in_progress,completed,cancelled,scheduled',
            'notes' => 'sometimes|string',
        ]);
        $record->update($validated);
        return response()->json($record->fresh());
    }

    public function destroy($id)
    {
        $record = $this->model::findOrFail($id);
        $record->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

}

