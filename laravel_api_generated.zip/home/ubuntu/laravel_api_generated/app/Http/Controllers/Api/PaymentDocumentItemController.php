<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\PaymentDocumentItem;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class PaymentDocumentItemController extends Controller
{
    private string $model = PaymentDocumentItem::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'document_id' => 'required|integer',
            'description' => 'required|string',
            'quantity' => 'required|numeric',
            'unit_price_mad' => 'required|numeric',
            'total_mad' => 'required|numeric',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    public function show($id)
    {
        return response()->json($this->model::findOrFail($id));
    }

    public function update(Request $request, $id)
    {
        $record = $this->model::findOrFail($id);
        $validated = $request->validate([
            'document_id' => 'sometimes|integer',
            'description' => 'sometimes|string',
            'quantity' => 'sometimes|numeric',
            'unit_price_mad' => 'sometimes|numeric',
            'total_mad' => 'sometimes|numeric',
        ]);
        $record->update($validated);
        return response()->json($record->fresh());
    }

    public function destroy($id)
    {
        $record = $this->model::findOrFail($id);
        $record->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

    public function byPaymentDocument($document_id)
    {
        return response()->json($this->model::where('document_id', $document_id)->paginate(request()->integer('per_page', 15)));
    }

}

