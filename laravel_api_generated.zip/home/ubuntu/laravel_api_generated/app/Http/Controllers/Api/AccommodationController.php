<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Accommodation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class AccommodationController extends Controller
{
    private string $model = Accommodation::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'public_id' => 'required|string',
            'name' => 'required|string',
            'type' => 'required|in:hotel,kasbah,bivouac_camp,riad,refuge,hotel',
            'city_id' => 'nullable|integer',
            'address' => 'nullable|string',
            'contact_phone' => 'nullable|string',
            'contact_email' => 'nullable|string',
            'reception_whatsapp' => 'nullable|string',
            'active' => 'required|boolean',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    public function show($id)
    {
        return response()->json($this->model::findOrFail($id));
    }

    public function update(Request $request, $id)
    {
        $record = $this->model::findOrFail($id);
        $validated = $request->validate([
            'public_id' => 'sometimes|string',
            'name' => 'sometimes|string',
            'type' => 'sometimes|in:hotel,kasbah,bivouac_camp,riad,refuge,hotel',
            'city_id' => 'sometimes|integer',
            'address' => 'sometimes|string',
            'contact_phone' => 'sometimes|string',
            'contact_email' => 'sometimes|string',
            'reception_whatsapp' => 'sometimes|string',
            'active' => 'sometimes|boolean',
        ]);
        $record->update($validated);
        return response()->json($record->fresh());
    }

    public function destroy($id)
    {
        $record = $this->model::findOrFail($id);
        $record->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

    public function byCity($city_id)
    {
        return response()->json($this->model::where('city_id', $city_id)->paginate(request()->integer('per_page', 15)));
    }

}

