<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class CategoryController extends Controller
{
    private string $model = Category::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'public_id' => 'required|string',
            'name' => 'required|string',
            'color' => 'nullable|string',
            'icon_name' => 'nullable|string',
            'active' => 'required|boolean',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    public function show($id)
    {
        return response()->json($this->model::findOrFail($id));
    }

    public function update(Request $request, $id)
    {
        $record = $this->model::findOrFail($id);
        $validated = $request->validate([
            'public_id' => 'sometimes|string',
            'name' => 'sometimes|string',
            'color' => 'sometimes|string',
            'icon_name' => 'sometimes|string',
            'active' => 'sometimes|boolean',
        ]);
        $record->update($validated);
        return response()->json($record->fresh());
    }

    public function destroy($id)
    {
        $record = $this->model::findOrFail($id);
        $record->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

}

