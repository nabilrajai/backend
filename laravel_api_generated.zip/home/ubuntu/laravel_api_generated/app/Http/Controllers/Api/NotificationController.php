<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Notification;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class NotificationController extends Controller
{
    private string $model = Notification::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'user_id' => 'nullable|integer',
            'category' => 'required|in:operations,finance,reservations,loyalty,content,system',
            'title' => 'required|string',
            'message' => 'required|string',
            'priority' => 'required|in:high,normal,low,normal',
            'action_link' => 'nullable|string',
            'action_label' => 'nullable|string',
            'read_at' => 'nullable|date',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    public function show($id)
    {
        return response()->json($this->model::findOrFail($id));
    }

    public function update(Request $request, $id)
    {
        $record = $this->model::findOrFail($id);
        $validated = $request->validate([
            'user_id' => 'sometimes|integer',
            'category' => 'sometimes|in:operations,finance,reservations,loyalty,content,system',
            'title' => 'sometimes|string',
            'message' => 'sometimes|string',
            'priority' => 'sometimes|in:high,normal,low,normal',
            'action_link' => 'sometimes|string',
            'action_label' => 'sometimes|string',
            'read_at' => 'sometimes|date',
        ]);
        $record->update($validated);
        return response()->json($record->fresh());
    }

    public function destroy($id)
    {
        $record = $this->model::findOrFail($id);
        $record->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

    public function byUser($user_id)
    {
        return response()->json($this->model::where('user_id', $user_id)->paginate(request()->integer('per_page', 15)));
    }

}

