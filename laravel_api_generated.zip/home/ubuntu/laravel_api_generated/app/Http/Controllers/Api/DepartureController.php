<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Departure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class DepartureController extends Controller
{
    private string $model = Departure::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'public_id' => 'required|string',
            'code' => 'required|string',
            'trip_id' => 'required|integer',
            'start_at' => 'required|date',
            'end_at' => 'nullable|date',
            'capacity' => 'required|integer',
            'status' => 'required|in:draft,open,almost_full,full,in_progress,completed,cancelled,draft',
            'guide_user_id' => 'nullable|integer',
            'vehicle_id' => 'nullable|integer',
            'guide_name' => 'nullable|string',
            'guide_phone' => 'nullable|string',
            'vehicle_label' => 'nullable|string',
            'pickup_location_fr' => 'nullable|string',
            'pickup_location_en' => 'nullable|string',
            'price_mad' => 'required|numeric',
            'notes_fr' => 'nullable|string',
            'notes_en' => 'nullable|string',
            'created_by' => 'nullable|integer',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    public function show($id)
    {
        return response()->json($this->model::findOrFail($id));
    }

    public function update(Request $request, $id)
    {
        $record = $this->model::findOrFail($id);
        $validated = $request->validate([
            'public_id' => 'sometimes|string',
            'code' => 'sometimes|string',
            'trip_id' => 'sometimes|integer',
            'start_at' => 'sometimes|date',
            'end_at' => 'sometimes|date',
            'capacity' => 'sometimes|integer',
            'status' => 'sometimes|in:draft,open,almost_full,full,in_progress,completed,cancelled,draft',
            'guide_user_id' => 'sometimes|integer',
            'vehicle_id' => 'sometimes|integer',
            'guide_name' => 'sometimes|string',
            'guide_phone' => 'sometimes|string',
            'vehicle_label' => 'sometimes|string',
            'pickup_location_fr' => 'sometimes|string',
            'pickup_location_en' => 'sometimes|string',
            'price_mad' => 'sometimes|numeric',
            'notes_fr' => 'sometimes|string',
            'notes_en' => 'sometimes|string',
            'created_by' => 'sometimes|integer',
        ]);
        $record->update($validated);
        return response()->json($record->fresh());
    }

    public function destroy($id)
    {
        $record = $this->model::findOrFail($id);
        $record->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

    public function byTrip($trip_id)
    {
        return response()->json($this->model::where('trip_id', $trip_id)->paginate(request()->integer('per_page', 15)));
    }

}

