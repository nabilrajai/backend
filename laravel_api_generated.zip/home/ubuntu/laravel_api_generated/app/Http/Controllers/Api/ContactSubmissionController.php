<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ContactSubmission;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ContactSubmissionController extends Controller
{
    private string $model = ContactSubmission::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'public_id' => 'required|string',
            'name' => 'required|string',
            'email' => 'required|string',
            'phone' => 'nullable|string',
            'subject' => 'nullable|string',
            'message' => 'required|string',
            'status' => 'required|in:new,in_progress,replied,closed,spam,new',
            'assigned_to' => 'nullable|integer',
            'replied_at' => 'nullable|date',
            'internal_notes' => 'nullable|string',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    public function show($id)
    {
        return response()->json($this->model::findOrFail($id));
    }

    public function update(Request $request, $id)
    {
        $record = $this->model::findOrFail($id);
        $validated = $request->validate([
            'public_id' => 'sometimes|string',
            'name' => 'sometimes|string',
            'email' => 'sometimes|string',
            'phone' => 'sometimes|string',
            'subject' => 'sometimes|string',
            'message' => 'sometimes|string',
            'status' => 'sometimes|in:new,in_progress,replied,closed,spam,new',
            'assigned_to' => 'sometimes|integer',
            'replied_at' => 'sometimes|date',
            'internal_notes' => 'sometimes|string',
        ]);
        $record->update($validated);
        return response()->json($record->fresh());
    }

    public function destroy($id)
    {
        $record = $this->model::findOrFail($id);
        $record->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

    public function byUser($assigned_to)
    {
        return response()->json($this->model::where('assigned_to', $assigned_to)->paginate(request()->integer('per_page', 15)));
    }

}

