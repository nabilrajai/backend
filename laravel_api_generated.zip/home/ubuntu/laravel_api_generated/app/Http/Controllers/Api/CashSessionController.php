<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\CashSession;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class CashSessionController extends Controller
{
    private string $model = CashSession::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'opened_by' => 'required|integer',
            'opened_at' => 'required|date',
            'opening_balance_mad' => 'required|numeric',
            'closed_by' => 'nullable|integer',
            'closed_at' => 'nullable|date',
            'closing_balance_mad' => 'nullable|numeric',
            'counted_balance_mad' => 'nullable|numeric',
            'variance_mad' => 'nullable|numeric',
            'status' => 'required|in:open,closed,open',
            'notes' => 'nullable|string',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    public function show($id)
    {
        return response()->json($this->model::findOrFail($id));
    }

    public function update(Request $request, $id)
    {
        $record = $this->model::findOrFail($id);
        $validated = $request->validate([
            'opened_by' => 'sometimes|integer',
            'opened_at' => 'sometimes|date',
            'opening_balance_mad' => 'sometimes|numeric',
            'closed_by' => 'sometimes|integer',
            'closed_at' => 'sometimes|date',
            'closing_balance_mad' => 'sometimes|numeric',
            'counted_balance_mad' => 'sometimes|numeric',
            'variance_mad' => 'sometimes|numeric',
            'status' => 'sometimes|in:open,closed,open',
            'notes' => 'sometimes|string',
        ]);
        $record->update($validated);
        return response()->json($record->fresh());
    }

    public function destroy($id)
    {
        $record = $this->model::findOrFail($id);
        $record->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

    public function byUser($opened_by)
    {
        return response()->json($this->model::where('opened_by', $opened_by)->paginate(request()->integer('per_page', 15)));
    }

}

