<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Bus;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class BusController extends Controller
{
    private string $model = Bus::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'public_id' => 'required|string',
            'matricule' => 'required|string',
            'name' => 'required|string',
            'brand' => 'required|string',
            'model' => 'required|string',
            'bus_type' => 'required|in:minibus,autocar,midibus,van_luxe,minibus',
            'capacity_seats' => 'required|integer',
            'year_manufactured' => 'nullable|integer',
            'driver_name' => 'nullable|string',
            'driver_phone' => 'nullable|string',
            'owner_type' => 'required|in:internal,rental_partner,internal',
            'partner_company' => 'nullable|string',
            'status' => 'required|in:active,maintenance,out_of_service,active',
            'mileage_km' => 'required|integer',
            'amenities' => 'nullable|array',
            'notes' => 'nullable|string',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    public function show($id)
    {
        return response()->json($this->model::findOrFail($id));
    }

    public function update(Request $request, $id)
    {
        $record = $this->model::findOrFail($id);
        $validated = $request->validate([
            'public_id' => 'sometimes|string',
            'matricule' => 'sometimes|string',
            'name' => 'sometimes|string',
            'brand' => 'sometimes|string',
            'model' => 'sometimes|string',
            'bus_type' => 'sometimes|in:minibus,autocar,midibus,van_luxe,minibus',
            'capacity_seats' => 'sometimes|integer',
            'year_manufactured' => 'sometimes|integer',
            'driver_name' => 'sometimes|string',
            'driver_phone' => 'sometimes|string',
            'owner_type' => 'sometimes|in:internal,rental_partner,internal',
            'partner_company' => 'sometimes|string',
            'status' => 'sometimes|in:active,maintenance,out_of_service,active',
            'mileage_km' => 'sometimes|integer',
            'amenities' => 'sometimes|array',
            'notes' => 'sometimes|string',
        ]);
        $record->update($validated);
        return response()->json($record->fresh());
    }

    public function destroy($id)
    {
        $record = $this->model::findOrFail($id);
        $record->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

}

