<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\SupportTicket;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class SupportTicketController extends Controller
{
    private string $model = SupportTicket::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'public_id' => 'required|string',
            'ticket_number' => 'required|string',
            'requester_user_id' => 'nullable|integer',
            'requester_name' => 'required|string',
            'requester_email' => 'nullable|string',
            'subject' => 'required|string',
            'category' => 'required|in:technical,reservation,payment,departure,content,other,other',
            'priority' => 'required|in:low,normal,high,urgent,normal',
            'status' => 'required|in:open,in_progress,waiting_customer,resolved,closed,open',
            'assigned_to' => 'nullable|integer',
            'description' => 'required|string',
            'resolution' => 'nullable|string',
            'resolved_at' => 'nullable|date',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    public function show($id)
    {
        return response()->json($this->model::findOrFail($id));
    }

    public function update(Request $request, $id)
    {
        $record = $this->model::findOrFail($id);
        $validated = $request->validate([
            'public_id' => 'sometimes|string',
            'ticket_number' => 'sometimes|string',
            'requester_user_id' => 'sometimes|integer',
            'requester_name' => 'sometimes|string',
            'requester_email' => 'sometimes|string',
            'subject' => 'sometimes|string',
            'category' => 'sometimes|in:technical,reservation,payment,departure,content,other,other',
            'priority' => 'sometimes|in:low,normal,high,urgent,normal',
            'status' => 'sometimes|in:open,in_progress,waiting_customer,resolved,closed,open',
            'assigned_to' => 'sometimes|integer',
            'description' => 'sometimes|string',
            'resolution' => 'sometimes|string',
            'resolved_at' => 'sometimes|date',
        ]);
        $record->update($validated);
        return response()->json($record->fresh());
    }

    public function destroy($id)
    {
        $record = $this->model::findOrFail($id);
        $record->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

    public function byUser($requester_user_id)
    {
        return response()->json($this->model::where('requester_user_id', $requester_user_id)->paginate(request()->integer('per_page', 15)));
    }

}

