<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\GalleryParticipant;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class GalleryParticipantController extends Controller
{
    private string $model = GalleryParticipant::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'gallery_id' => 'required|integer',
            'customer_id' => 'nullable|integer',
            'traveler_id' => 'nullable|integer',
            'email' => 'nullable|string',
            'confirmed' => 'required|boolean',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    public function show($id)
    {
        return response()->json($this->model::findOrFail($id));
    }

    public function update(Request $request, $id)
    {
        $record = $this->model::findOrFail($id);
        $validated = $request->validate([
            'gallery_id' => 'sometimes|integer',
            'customer_id' => 'sometimes|integer',
            'traveler_id' => 'sometimes|integer',
            'email' => 'sometimes|string',
            'confirmed' => 'sometimes|boolean',
        ]);
        $record->update($validated);
        return response()->json($record->fresh());
    }

    public function destroy($id)
    {
        $record = $this->model::findOrFail($id);
        $record->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

    public function byGallery($gallery_id)
    {
        return response()->json($this->model::where('gallery_id', $gallery_id)->paginate(request()->integer('per_page', 15)));
    }

}

