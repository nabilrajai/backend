<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\LoyaltyReward;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class LoyaltyRewardController extends Controller
{
    private string $model = LoyaltyReward::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'public_id' => 'required|string',
            'name' => 'required|string',
            'category' => 'required|in:discount,upgrade,experience,vip_service',
            'points_cost' => 'required|integer',
            'description' => 'nullable|string',
            'claimed_count' => 'required|integer',
            'stock' => 'nullable|integer',
            'value_mad' => 'required|numeric',
            'active' => 'required|boolean',
            'created_by' => 'nullable|integer',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    public function show($id)
    {
        return response()->json($this->model::findOrFail($id));
    }

    public function update(Request $request, $id)
    {
        $record = $this->model::findOrFail($id);
        $validated = $request->validate([
            'public_id' => 'sometimes|string',
            'name' => 'sometimes|string',
            'category' => 'sometimes|in:discount,upgrade,experience,vip_service',
            'points_cost' => 'sometimes|integer',
            'description' => 'sometimes|string',
            'claimed_count' => 'sometimes|integer',
            'stock' => 'sometimes|integer',
            'value_mad' => 'sometimes|numeric',
            'active' => 'sometimes|boolean',
            'created_by' => 'sometimes|integer',
        ]);
        $record->update($validated);
        return response()->json($record->fresh());
    }

    public function destroy($id)
    {
        $record = $this->model::findOrFail($id);
        $record->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

    public function byUser($created_by)
    {
        return response()->json($this->model::where('created_by', $created_by)->paginate(request()->integer('per_page', 15)));
    }

}

