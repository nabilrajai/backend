<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\DestinationTrip;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class DestinationTripController extends Controller
{
    private string $model = DestinationTrip::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'destination_id' => 'required|integer',
            'trip_id' => 'required|integer',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    private function keyQuery(Request $request)
    {
        return $this->model::query()->where(['destination_id' => $request->input('destination_id'), 'trip_id' => $request->input('trip_id')]);
    }

    public function show(Request $request)
    {
        return response()->json($this->keyQuery($request)->firstOrFail());
    }

    public function update(Request $request)
    {
        $record = $this->keyQuery($request)->firstOrFail();
        $validated = $request->validate([
            'destination_id' => 'sometimes|integer',
            'trip_id' => 'sometimes|integer',
        ]);
        $record->forceFill($validated)->save();
        return response()->json($record->fresh());
    }

    public function destroy(Request $request)
    {
        $this->keyQuery($request)->firstOrFail()->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

    public function byDestination($destination_id)
    {
        return response()->json($this->model::where('destination_id', $destination_id)->paginate(request()->integer('per_page', 15)));
    }

}

