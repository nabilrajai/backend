<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\BusDocument;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class BusDocumentController extends Controller
{
    private string $model = BusDocument::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'public_id' => 'required|string',
            'bus_id' => 'required|integer',
            'document_type' => 'required|in:assurance,visite_technique,vignette,licence_tourisme,carte_grise,tachygraphe,extincteur,autre',
            'title' => 'required|string',
            'reference_number' => 'nullable|string',
            'provider' => 'nullable|string',
            'issue_date' => 'nullable|date',
            'expiry_date' => 'required|date',
            'cost_mad' => 'required|numeric',
            'file_url' => 'nullable|string',
            'notes' => 'nullable|string',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    public function show($id)
    {
        return response()->json($this->model::findOrFail($id));
    }

    public function update(Request $request, $id)
    {
        $record = $this->model::findOrFail($id);
        $validated = $request->validate([
            'public_id' => 'sometimes|string',
            'bus_id' => 'sometimes|integer',
            'document_type' => 'sometimes|in:assurance,visite_technique,vignette,licence_tourisme,carte_grise,tachygraphe,extincteur,autre',
            'title' => 'sometimes|string',
            'reference_number' => 'sometimes|string',
            'provider' => 'sometimes|string',
            'issue_date' => 'sometimes|date',
            'expiry_date' => 'sometimes|date',
            'cost_mad' => 'sometimes|numeric',
            'file_url' => 'sometimes|string',
            'notes' => 'sometimes|string',
        ]);
        $record->update($validated);
        return response()->json($record->fresh());
    }

    public function destroy($id)
    {
        $record = $this->model::findOrFail($id);
        $record->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

}

