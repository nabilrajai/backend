<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class CustomerController extends Controller
{
    private string $model = Customer::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'public_id' => 'required|string',
            'first_name' => 'required|string',
            'last_name' => 'required|string',
            'email' => 'nullable|string',
            'phone' => 'nullable|string',
            'cin' => 'nullable|string',
            'passport_number' => 'nullable|string',
            'city' => 'nullable|string',
            'country' => 'nullable|string',
            'preferred_language' => 'nullable|string',
            'status' => 'required|in:active,needs_review,inactive,active',
            'marketing_opt_in' => 'required|boolean',
            'notes' => 'nullable|string',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    public function show($id)
    {
        return response()->json($this->model::findOrFail($id));
    }

    public function update(Request $request, $id)
    {
        $record = $this->model::findOrFail($id);
        $validated = $request->validate([
            'public_id' => 'sometimes|string',
            'first_name' => 'sometimes|string',
            'last_name' => 'sometimes|string',
            'email' => 'sometimes|string',
            'phone' => 'sometimes|string',
            'cin' => 'sometimes|string',
            'passport_number' => 'sometimes|string',
            'city' => 'sometimes|string',
            'country' => 'sometimes|string',
            'preferred_language' => 'sometimes|string',
            'status' => 'sometimes|in:active,needs_review,inactive,active',
            'marketing_opt_in' => 'sometimes|boolean',
            'notes' => 'sometimes|string',
        ]);
        $record->update($validated);
        return response()->json($record->fresh());
    }

    public function destroy($id)
    {
        $record = $this->model::findOrFail($id);
        $record->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

}

