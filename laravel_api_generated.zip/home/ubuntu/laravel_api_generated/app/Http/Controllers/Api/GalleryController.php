<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Gallery;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class GalleryController extends Controller
{
    private string $model = Gallery::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'public_id' => 'required|string',
            'departure_id' => 'required|integer',
            'access' => 'required|in:participants_private,public,team_guide,participants_private',
            'published' => 'required|boolean',
            'cover_url' => 'nullable|string',
            'private_share_token' => 'nullable|string',
            'download_count' => 'required|integer',
            'created_by' => 'nullable|integer',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    public function show($id)
    {
        return response()->json($this->model::findOrFail($id));
    }

    public function update(Request $request, $id)
    {
        $record = $this->model::findOrFail($id);
        $validated = $request->validate([
            'public_id' => 'sometimes|string',
            'departure_id' => 'sometimes|integer',
            'access' => 'sometimes|in:participants_private,public,team_guide,participants_private',
            'published' => 'sometimes|boolean',
            'cover_url' => 'sometimes|string',
            'private_share_token' => 'sometimes|string',
            'download_count' => 'sometimes|integer',
            'created_by' => 'sometimes|integer',
        ]);
        $record->update($validated);
        return response()->json($record->fresh());
    }

    public function destroy($id)
    {
        $record = $this->model::findOrFail($id);
        $record->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

    public function byDeparture($departure_id)
    {
        return response()->json($this->model::where('departure_id', $departure_id)->paginate(request()->integer('per_page', 15)));
    }

}

