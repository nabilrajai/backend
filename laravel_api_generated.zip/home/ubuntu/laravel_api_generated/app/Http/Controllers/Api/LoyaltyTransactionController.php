<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\LoyaltyTransaction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class LoyaltyTransactionController extends Controller
{
    private string $model = LoyaltyTransaction::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'loyalty_member_id' => 'required|integer',
            'type' => 'required|in:credit,debit,adjustment,expiry',
            'points' => 'required|integer',
            'reason' => 'required|string',
            'balance_after' => 'required|integer',
            'reservation_id' => 'nullable|integer',
            'reward_id' => 'nullable|integer',
            'signatory_id' => 'nullable|integer',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    public function show($id)
    {
        return response()->json($this->model::findOrFail($id));
    }

    public function update(Request $request, $id)
    {
        $record = $this->model::findOrFail($id);
        $validated = $request->validate([
            'loyalty_member_id' => 'sometimes|integer',
            'type' => 'sometimes|in:credit,debit,adjustment,expiry',
            'points' => 'sometimes|integer',
            'reason' => 'sometimes|string',
            'balance_after' => 'sometimes|integer',
            'reservation_id' => 'sometimes|integer',
            'reward_id' => 'sometimes|integer',
            'signatory_id' => 'sometimes|integer',
        ]);
        $record->update($validated);
        return response()->json($record->fresh());
    }

    public function destroy($id)
    {
        $record = $this->model::findOrFail($id);
        $record->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

    public function byLoyaltyMember($loyalty_member_id)
    {
        return response()->json($this->model::where('loyalty_member_id', $loyalty_member_id)->paginate(request()->integer('per_page', 15)));
    }

}

