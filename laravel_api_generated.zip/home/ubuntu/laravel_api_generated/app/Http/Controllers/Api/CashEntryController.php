<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\CashEntry;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class CashEntryController extends Controller
{
    private string $model = CashEntry::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'session_id' => 'nullable|integer',
            'reference' => 'required|string',
            'type' => 'required|in:in,out',
            'category' => 'required|in:reservation_advance,stay_balance,fuel,guide_expense,toll,camp_supplies,misc',
            'description' => 'required|string',
            'amount_mad' => 'required|numeric',
            'occurred_at' => 'required|date',
            'cashier_id' => 'nullable|integer',
            'trip_id' => 'nullable|integer',
            'reservation_id' => 'nullable|integer',
            'client_name' => 'nullable|string',
            'justification_reference' => 'nullable|string',
            'notes' => 'nullable|string',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    public function show($id)
    {
        return response()->json($this->model::findOrFail($id));
    }

    public function update(Request $request, $id)
    {
        $record = $this->model::findOrFail($id);
        $validated = $request->validate([
            'session_id' => 'sometimes|integer',
            'reference' => 'sometimes|string',
            'type' => 'sometimes|in:in,out',
            'category' => 'sometimes|in:reservation_advance,stay_balance,fuel,guide_expense,toll,camp_supplies,misc',
            'description' => 'sometimes|string',
            'amount_mad' => 'sometimes|numeric',
            'occurred_at' => 'sometimes|date',
            'cashier_id' => 'sometimes|integer',
            'trip_id' => 'sometimes|integer',
            'reservation_id' => 'sometimes|integer',
            'client_name' => 'sometimes|string',
            'justification_reference' => 'sometimes|string',
            'notes' => 'sometimes|string',
        ]);
        $record->update($validated);
        return response()->json($record->fresh());
    }

    public function destroy($id)
    {
        $record = $this->model::findOrFail($id);
        $record->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

    public function byCashSession($session_id)
    {
        return response()->json($this->model::where('session_id', $session_id)->paginate(request()->integer('per_page', 15)));
    }

}

