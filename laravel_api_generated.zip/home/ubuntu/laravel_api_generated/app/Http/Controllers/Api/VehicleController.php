<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Vehicle;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class VehicleController extends Controller
{
    private string $model = Vehicle::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'public_id' => 'required|string',
            'matricule' => 'required|string',
            'model' => 'required|string',
            'vehicle_type' => 'required|in:minibus,4x4,van_luxe,autocar,minibus',
            'capacity_seats' => 'required|integer',
            'owner_type' => 'required|in:internal,rental_partner,internal',
            'partner_name' => 'nullable|string',
            'license_number' => 'nullable|string',
            'insurance_expiry' => 'nullable|date',
            'inspection_expiry' => 'nullable|date',
            'active' => 'required|boolean',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    public function show($id)
    {
        return response()->json($this->model::findOrFail($id));
    }

    public function update(Request $request, $id)
    {
        $record = $this->model::findOrFail($id);
        $validated = $request->validate([
            'public_id' => 'sometimes|string',
            'matricule' => 'sometimes|string',
            'model' => 'sometimes|string',
            'vehicle_type' => 'sometimes|in:minibus,4x4,van_luxe,autocar,minibus',
            'capacity_seats' => 'sometimes|integer',
            'owner_type' => 'sometimes|in:internal,rental_partner,internal',
            'partner_name' => 'sometimes|string',
            'license_number' => 'sometimes|string',
            'insurance_expiry' => 'sometimes|date',
            'inspection_expiry' => 'sometimes|date',
            'active' => 'sometimes|boolean',
        ]);
        $record->update($validated);
        return response()->json($record->fresh());
    }

    public function destroy($id)
    {
        $record = $this->model::findOrFail($id);
        $record->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

}

