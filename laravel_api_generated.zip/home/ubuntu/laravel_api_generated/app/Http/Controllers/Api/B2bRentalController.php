<?php

namespace App\Http\Controllers\Api;

use App\Models\B2bClient;
use App\Models\BusRental;
use App\Models\BusRentalExpense;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class B2bRentalController
{
    public function clients(Request $request)
    {
        return response()->json(B2bClient::query()->latest('created_at')->paginate($request->integer('per_page', 50)));
    }

    public function storeClient(Request $request)
    {
        $data = $request->validate(['company_name' => 'required|string|max:220', 'contact_name' => 'required|string|max:160', 'email' => 'nullable|email', 'phone' => 'required|string|max:60', 'tax_id' => 'nullable|string|max:100', 'address' => 'nullable|string', 'city' => 'nullable|string|max:120', 'country' => 'nullable|string|max:120', 'notes' => 'nullable|string', 'status' => 'nullable|in:active,inactive']);
        $data['public_id'] = (string) Str::uuid();
        return response()->json(B2bClient::create($data), 201);
    }

    public function showClient(int $id)
    {
        return response()->json(B2bClient::withCount('rentals')->findOrFail($id));
    }

    public function updateClient(Request $request, int $id)
    {
        $client = B2bClient::findOrFail($id);
        $client->update($request->validate(['company_name' => 'sometimes|string|max:220', 'contact_name' => 'sometimes|string|max:160', 'email' => 'nullable|email', 'phone' => 'sometimes|string|max:60', 'tax_id' => 'nullable|string|max:100', 'address' => 'nullable|string', 'city' => 'nullable|string|max:120', 'country' => 'nullable|string|max:120', 'notes' => 'nullable|string', 'status' => 'nullable|in:active,inactive']));
        return response()->json($client->fresh());
    }

    public function deleteClient(int $id)
    {
        B2bClient::findOrFail($id)->delete();
        return response()->json(['message' => 'B2B client deleted successfully']);
    }

    public function rentals(Request $request)
    {
        $query = BusRental::with(['client:id,company_name,contact_name', 'bus:id,matricule,name,model'])->withSum('expenses', 'amount_mad')->latest('start_at');
        if ($request->filled('status')) $query->where('status', $request->string('status'));
        if ($request->filled('from')) $query->where('end_at', '>=', $request->date('from'));
        if ($request->filled('to')) $query->where('start_at', '<=', $request->date('to'));
        return response()->json($query->paginate($request->integer('per_page', 50)));
    }

    public function storeRental(Request $request)
    {
        $data = $request->validate(['b2b_client_id' => 'required|exists:b2b_clients,id', 'bus_id' => 'required|exists:buses,id', 'contract_reference' => 'required|string|max:100|unique:bus_rentals,contract_reference', 'trip_name' => 'required|string|max:220', 'pickup_location' => 'required|string|max:255', 'destination' => 'required|string|max:255', 'start_at' => 'required|date', 'end_at' => 'required|date|after:start_at', 'agreed_price_mad' => 'required|numeric|min:0', 'status' => 'nullable|in:draft,confirmed,in_progress,completed,cancelled', 'driver_included' => 'boolean', 'driver_name' => 'nullable|string|max:160', 'driver_phone' => 'nullable|string|max:60', 'notes' => 'nullable|string']);
        $this->assertAvailable($data['bus_id'], $data['start_at'], $data['end_at']);
        $data['public_id'] = (string) Str::uuid();
        $data['created_by'] = auth()->id();
        return response()->json(BusRental::create($data)->load(['client', 'bus']), 201);
    }

    public function showRental(int $id)
    {
        return response()->json(BusRental::with(['client', 'bus', 'expenses'])->withSum('expenses', 'amount_mad')->findOrFail($id));
    }

    public function updateRental(Request $request, int $id)
    {
        $rental = BusRental::findOrFail($id);
        $data = $request->validate(['b2b_client_id' => 'sometimes|exists:b2b_clients,id', 'bus_id' => 'sometimes|exists:buses,id', 'contract_reference' => 'sometimes|string|max:100|unique:bus_rentals,contract_reference,'.$id, 'trip_name' => 'sometimes|string|max:220', 'pickup_location' => 'sometimes|string|max:255', 'destination' => 'sometimes|string|max:255', 'start_at' => 'sometimes|date', 'end_at' => 'sometimes|date|after:start_at', 'agreed_price_mad' => 'sometimes|numeric|min:0', 'status' => 'sometimes|in:draft,confirmed,in_progress,completed,cancelled', 'driver_included' => 'sometimes|boolean', 'driver_name' => 'nullable|string|max:160', 'driver_phone' => 'nullable|string|max:60', 'notes' => 'nullable|string']);
        $busId = $data['bus_id'] ?? $rental->bus_id;
        $start = $data['start_at'] ?? $rental->start_at;
        $end = $data['end_at'] ?? $rental->end_at;
        $this->assertAvailable($busId, $start, $end, $rental->id);
        $rental->update($data);
        return response()->json($rental->fresh()->load(['client', 'bus'])->loadSum('expenses', 'amount_mad'));
    }

    public function deleteRental(int $id)
    {
        BusRental::findOrFail($id)->delete();
        return response()->json(['message' => 'B2B rental deleted successfully']);
    }

    public function availability(Request $request)
    {
        $data = $request->validate(['start_at' => 'required|date', 'end_at' => 'required|date|after:start_at', 'bus_id' => 'nullable|integer']);
        $query = DB::table('buses')->where('buses.status', 'active')->whereNull('buses.deleted_at');
        if (!empty($data['bus_id'])) $query->where('buses.id', $data['bus_id']);
        $query->whereNotExists(function ($q) use ($data) { $q->selectRaw('1')->from('bus_rentals')->whereColumn('bus_rentals.bus_id', 'buses.id')->whereNull('bus_rentals.deleted_at')->whereNotIn('bus_rentals.status', ['cancelled', 'completed'])->where('bus_rentals.start_at', '<', $data['end_at'])->where('bus_rentals.end_at', '>', $data['start_at']); });
        $query->whereNotExists(function ($q) use ($data) { $q->selectRaw('1')->from('bus_departures')->whereColumn('bus_departures.bus_id', 'buses.id')->whereIn('bus_departures.status', ['scheduled', 'in_progress'])->where('bus_departures.start_date', '<=', substr($data['end_at'], 0, 10))->where('bus_departures.end_date', '>=', substr($data['start_at'], 0, 10)); });
        return response()->json(['available' => $query->orderBy('buses.name')->get()]);
    }

    public function calendar(Request $request)
    {
        $month = $request->input('month', now()->format('Y-m'));
        return response()->json(['month' => $month, 'rentals' => BusRental::with(['client:id,company_name', 'bus:id,matricule,name'])->where('start_at', '<', date('Y-m-t 23:59:59', strtotime($month.'-01')))->where('end_at', '>=', date('Y-m-01 00:00:00', strtotime($month.'-01')))->orderBy('start_at')->get()]);
    }

    public function expenses(int $rentalId)
    {
        $rental = BusRental::findOrFail($rentalId);
        return response()->json(['expenses' => $rental->expenses()->latest('expense_date')->get(), 'total_expense_mad' => (float) $rental->expenses()->sum('amount_mad'), 'agreed_price_mad' => (float) $rental->agreed_price_mad, 'net_profit_mad' => (float) $rental->agreed_price_mad - (float) $rental->expenses()->sum('amount_mad')]);
    }

    public function storeExpense(Request $request, int $rentalId)
    {
        BusRental::findOrFail($rentalId);
        $data = $request->validate(['category' => 'required|in:fuel,toll,driver,maintenance,parking,other', 'title' => 'required|string|max:200', 'amount_mad' => 'required|numeric|min:0', 'expense_date' => 'required|date', 'supplier' => 'nullable|string|max:160', 'notes' => 'nullable|string']);
        $data['public_id'] = (string) Str::uuid();
        $data['bus_rental_id'] = $rentalId;
        return response()->json(BusRentalExpense::create($data), 201);
    }

    public function deleteExpense(int $rentalId, int $expenseId)
    {
        BusRentalExpense::where('bus_rental_id', $rentalId)->findOrFail($expenseId)->delete();
        return response()->json(['message' => 'Rental expense deleted successfully']);
    }

    private function assertAvailable(int $busId, $startAt, $endAt, ?int $ignoreRentalId = null): void
    {
        $query = BusRental::query()->where('bus_id', $busId)->whereNull('deleted_at')->whereNotIn('status', ['cancelled', 'completed'])->where('start_at', '<', $endAt)->where('end_at', '>', $startAt);
        if ($ignoreRentalId) $query->where('id', '!=', $ignoreRentalId);
        if ($query->exists()) abort(response()->json(['message' => 'This bus is already rented during the selected period.', 'conflict' => true], 409));
        $internalConflict = DB::table('bus_departures')->where('bus_id', $busId)->whereIn('status', ['scheduled', 'in_progress'])->where('start_date', '<=', substr((string) $endAt, 0, 10))->where('end_date', '>=', substr((string) $startAt, 0, 10))->exists();
        if ($internalConflict) abort(response()->json(['message' => 'This bus is assigned to an internal departure during the selected period.', 'conflict' => true], 409));
    }
}
