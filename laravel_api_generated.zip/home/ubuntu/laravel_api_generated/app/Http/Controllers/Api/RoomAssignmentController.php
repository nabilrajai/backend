<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\RoomAssignment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class RoomAssignmentController extends Controller
{
    private string $model = RoomAssignment::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'departure_id' => 'required|integer',
            'reservation_id' => 'nullable|integer',
            'accommodation_id' => 'nullable|integer',
            'room_number' => 'required|string',
            'room_type' => 'required|in:single,double,triple,quadruple,suite,tente,double',
            'hotel_name' => 'nullable|string',
            'occupants' => 'nullable|array',
            'notes' => 'nullable|string',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    public function show($id)
    {
        return response()->json($this->model::findOrFail($id));
    }

    public function update(Request $request, $id)
    {
        $record = $this->model::findOrFail($id);
        $validated = $request->validate([
            'departure_id' => 'sometimes|integer',
            'reservation_id' => 'sometimes|integer',
            'accommodation_id' => 'sometimes|integer',
            'room_number' => 'sometimes|string',
            'room_type' => 'sometimes|in:single,double,triple,quadruple,suite,tente,double',
            'hotel_name' => 'sometimes|string',
            'occupants' => 'sometimes|array',
            'notes' => 'sometimes|string',
        ]);
        $record->update($validated);
        return response()->json($record->fresh());
    }

    public function destroy($id)
    {
        $record = $this->model::findOrFail($id);
        $record->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

    public function byDeparture($departure_id)
    {
        return response()->json($this->model::where('departure_id', $departure_id)->paginate(request()->integer('per_page', 15)));
    }

}

