<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\DeparturePresence;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class DeparturePresenceController extends Controller
{
    private string $model = DeparturePresence::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'departure_id' => 'required|integer',
            'reservation_id' => 'required|integer',
            'traveler_id' => 'nullable|integer',
            'seat_number' => 'nullable|string',
            'is_present' => 'required|boolean',
            'pickup_point_1' => 'nullable|string',
            'pickup_point_2' => 'nullable|string',
            'dropoff_point' => 'nullable|string',
            'checked_at' => 'nullable|date',
            'checked_by' => 'nullable|integer',
            'notes' => 'nullable|string',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    public function show($id)
    {
        return response()->json($this->model::findOrFail($id));
    }

    public function update(Request $request, $id)
    {
        $record = $this->model::findOrFail($id);
        $validated = $request->validate([
            'departure_id' => 'sometimes|integer',
            'reservation_id' => 'sometimes|integer',
            'traveler_id' => 'sometimes|integer',
            'seat_number' => 'sometimes|string',
            'is_present' => 'sometimes|boolean',
            'pickup_point_1' => 'sometimes|string',
            'pickup_point_2' => 'sometimes|string',
            'dropoff_point' => 'sometimes|string',
            'checked_at' => 'sometimes|date',
            'checked_by' => 'sometimes|integer',
            'notes' => 'sometimes|string',
        ]);
        $record->update($validated);
        return response()->json($record->fresh());
    }

    public function destroy($id)
    {
        $record = $this->model::findOrFail($id);
        $record->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

    public function byDeparture($departure_id)
    {
        return response()->json($this->model::where('departure_id', $departure_id)->paginate(request()->integer('per_page', 15)));
    }

}

