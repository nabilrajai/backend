<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ReservationTraveler;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ReservationTravelerController extends Controller
{
    private string $model = ReservationTraveler::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'reservation_id' => 'required|integer',
            'customer_id' => 'nullable|integer',
            'full_name' => 'required|string',
            'document_type' => 'nullable|string',
            'document_number' => 'nullable|string',
            'qr_token' => 'nullable|string',
            'role' => 'nullable|string',
            'date_of_birth' => 'nullable|date',
            'nationality' => 'nullable|string',
            'phone' => 'nullable|string',
            'email' => 'nullable|string',
            'dietary_notes' => 'nullable|string',
            'accommodation_notes' => 'nullable|string',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    public function show($id)
    {
        return response()->json($this->model::findOrFail($id));
    }

    public function update(Request $request, $id)
    {
        $record = $this->model::findOrFail($id);
        $validated = $request->validate([
            'reservation_id' => 'sometimes|integer',
            'customer_id' => 'sometimes|integer',
            'full_name' => 'sometimes|string',
            'document_type' => 'sometimes|string',
            'document_number' => 'sometimes|string',
            'qr_token' => 'sometimes|string',
            'role' => 'sometimes|string',
            'date_of_birth' => 'sometimes|date',
            'nationality' => 'sometimes|string',
            'phone' => 'sometimes|string',
            'email' => 'sometimes|string',
            'dietary_notes' => 'sometimes|string',
            'accommodation_notes' => 'sometimes|string',
        ]);
        $record->update($validated);
        return response()->json($record->fresh());
    }

    public function destroy($id)
    {
        $record = $this->model::findOrFail($id);
        $record->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

    public function byReservation($reservation_id)
    {
        return response()->json($this->model::where('reservation_id', $reservation_id)->paginate(request()->integer('per_page', 15)));
    }

}

