<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class AdminApiController
{
    private function list(string $table, Request $request)
    {
        return response()->json(DB::table($table)->paginate($request->integer('per_page', 50)));
    }

    public function health()
    {
        try {
            DB::select('SELECT 1');
            return response()->json(['success' => true, 'database' => ['connected' => true]]);
        } catch (\Throwable $e) {
            return response()->json(['success' => false, 'database' => ['connected' => false]], 503);
        }
    }

    public function dashboard()
    {
        return response()->json([
            'success' => true,
            'counts' => [
                'reservations' => DB::table('reservations')->count(),
                'customers' => DB::table('customers')->count(),
                'trips' => DB::table('trips')->count(),
                'departures' => DB::table('departures')->count(),
                'payments' => DB::table('payments')->count(),
            ],
            'revenue' => (float) DB::table('payments')->where('status', 'paid')->sum('amount_mad'),
            'recentReservations' => DB::table('reservations')->latest('created_at')->limit(10)->get(),
            'upcomingDepartures' => DB::table('departures')->whereIn('status', ['scheduled', 'open'])->orderBy('start_at')->limit(10)->get(),
        ]);
    }

    public function menuCounts()
    {
        return response()->json(['success' => true, 'counts' => [
            'reservations' => DB::table('reservations')->whereIn('status', ['pending', 'requested'])->count(),
            'contacts' => DB::table('contact_submissions')->where('status', 'new')->count(),
            'departures' => DB::table('departures')->whereIn('status', ['scheduled', 'open'])->count(),
            'customers' => DB::table('customers')->count(),
            'trips' => DB::table('trips')->count(),
            'buses' => DB::table('buses')->where('status', '!=', 'active')->count(),
        ]]);
    }

    public function departures(Request $request)
    {
        $query = DB::table('departures')->orderBy('start_at');
        if ($request->filled('status')) $query->where('status', $request->string('status'));
        return response()->json($query->paginate($request->integer('per_page', 50)));
    }

    public function rooming(int $departureId, Request $request)
    {
        return response()->json(DB::table('room_assignments')->where('departure_id', $departureId)->paginate($request->integer('per_page', 100)));
    }

    public function storeRoom(Request $request, int $departureId)
    {
        $data = $request->validate(['reservation_id' => 'nullable|integer', 'accommodation_id' => 'nullable|integer', 'room_number' => 'required|string', 'room_type' => 'nullable|string', 'hotel_name' => 'nullable|string', 'occupants' => 'nullable|array', 'notes' => 'nullable|string']);
        $data['departure_id'] = $departureId;
        $data['created_at'] = now();
        $id = DB::table('room_assignments')->insertGetId($data);
        return response()->json(DB::table('room_assignments')->find($id), 201);
    }

    public function updateRoom(Request $request, int $departureId, int $roomId)
    {
        $data = $request->validate(['reservation_id' => 'nullable|integer', 'accommodation_id' => 'nullable|integer', 'room_number' => 'sometimes|string', 'room_type' => 'nullable|string', 'hotel_name' => 'nullable|string', 'occupants' => 'nullable|array', 'notes' => 'nullable|string']);
        DB::table('room_assignments')->where('id', $roomId)->where('departure_id', $departureId)->update($data);
        return response()->json(DB::table('room_assignments')->find($roomId));
    }

    public function deleteRoom(int $departureId, int $roomId)
    {
        DB::table('room_assignments')->where('id', $roomId)->where('departure_id', $departureId)->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

    public function presence(int $departureId, Request $request)
    {
        return response()->json(DB::table('departure_presence')->where('departure_id', $departureId)->paginate($request->integer('per_page', 100)));
    }

    public function updatePresence(Request $request, int $departureId, int $presenceId)
    {
        $data = $request->validate(['seat_number' => 'nullable|string', 'is_present' => 'boolean', 'pickup_point_1' => 'nullable|string', 'pickup_point_2' => 'nullable|string', 'dropoff_point' => 'nullable|string', 'notes' => 'nullable|string']);
        DB::table('departure_presence')->where('id', $presenceId)->where('departure_id', $departureId)->update($data);
        return response()->json(DB::table('departure_presence')->find($presenceId));
    }

    public function departurePayments(int $departureId, Request $request)
    {
        return response()->json(DB::table('payments')->where('departure_id', $departureId)->latest('created_at')->paginate($request->integer('per_page', 50)));
    }

    public function storeDeparturePayment(Request $request, int $departureId)
    {
        $data = $request->validate(['reservation_id' => 'nullable|integer', 'customer_id' => 'nullable|integer', 'method' => 'required|string', 'amount_mad' => 'required|numeric', 'currency' => 'nullable|string', 'status' => 'nullable|string', 'payment_type' => 'nullable|string', 'notes' => 'nullable|string']);
        $data['departure_id'] = $departureId;
        $data['public_id'] = (string) Str::uuid();
        $data['reference'] = $data['reference'] ?? 'PAY-'.now()->format('ymdHis');
        $data['created_at'] = now();
        $id = DB::table('payments')->insertGetId($data);
        return response()->json(DB::table('payments')->find($id), 201);
    }

    public function departureActivities(int $departureId, Request $request)
    {
        return response()->json(DB::table('departure_activity_orders')->where('departure_id', $departureId)->paginate($request->integer('per_page', 50)));
    }

    public function storeDepartureActivity(Request $request, int $departureId)
    {
        $data = $request->validate(['reservation_id' => 'nullable|integer', 'activity_id' => 'nullable|integer', 'activity_name' => 'required|string', 'quantity' => 'required|integer', 'unit_price_mad' => 'required|numeric', 'scheduled_at' => 'nullable|date', 'payment_status' => 'nullable|string', 'payment_method' => 'nullable|string', 'notes' => 'nullable|string']);
        $data['departure_id'] = $departureId;
        $data['total_price_mad'] = $data['quantity'] * $data['unit_price_mad'];
        $id = DB::table('departure_activity_orders')->insertGetId($data);
        return response()->json(DB::table('departure_activity_orders')->find($id), 201);
    }

    public function deleteDepartureActivity(int $departureId, int $activityId)
    {
        DB::table('departure_activity_orders')->where('id', $activityId)->where('departure_id', $departureId)->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

    public function tripProgramme(Request $request, int $tripId)
    {
        $data = $request->validate(['steps' => 'nullable|array', 'program_html' => 'nullable|string', 'program_summary' => 'nullable|string']);
        $tripUpdate = array_filter(['program_html' => $data['program_html'] ?? null, 'program_summary' => $data['program_summary'] ?? null], fn ($v) => $v !== null);
        if ($tripUpdate) DB::table('trips')->where('id', $tripId)->update(array_merge($tripUpdate, ['updated_at' => now()]));
        if (isset($data['steps'])) {
            DB::table('trip_days')->where('trip_id', $tripId)->delete();
            foreach ($data['steps'] as $index => $step) DB::table('trip_days')->insert(['trip_id' => $tripId, 'day_number' => $index + 1, 'title' => is_array($step) ? ($step['title'] ?? 'Day '.($index + 1)) : 'Day '.($index + 1), 'description' => is_array($step) ? ($step['description'] ?? '') : (string) $step]);
        }
        return response()->json(['success' => true, 'trip' => DB::table('trips')->find($tripId), 'days' => DB::table('trip_days')->where('trip_id', $tripId)->orderBy('day_number')->get()]);
    }

    public function reservationByReference(string $reference)
    {
        $reservation = DB::table('reservations')->where('reference', $reference)->orWhere('qr_token', $reference)->firstOrFail();
        return response()->json($reservation);
    }

    public function scannerVerify(Request $request)
    {
        $code = $request->input('code', $request->input('qr_token'));
        $reservation = DB::table('reservations')->where('reference', $code)->orWhere('qr_token', $code)->first();
        return response()->json(['valid' => (bool) $reservation, 'reservation' => $reservation]);
    }

    public function scannerCheckin(Request $request)
    {
        $data = $request->validate(['reservation_id' => 'required|integer', 'departure_id' => 'nullable|integer', 'traveler_id' => 'nullable|integer']);
        $data['checked_at'] = now();
        $data['is_present'] = true;
        $data['departure_id'] = $data['departure_id'] ?? DB::table('reservations')->where('id', $data['reservation_id'])->value('departure_id');
        $id = DB::table('departure_presence')->insertGetId($data);
        return response()->json(['success' => true, 'presence' => DB::table('departure_presence')->find($id)], 201);
    }

    public function fleetSummary()
    {
        return response()->json(['success' => true, 'summary' => ['total' => DB::table('buses')->count(), 'active' => DB::table('buses')->where('status', 'active')->count(), 'maintenance' => DB::table('buses')->where('status', 'maintenance')->count(), 'out_of_service' => DB::table('buses')->where('status', 'out_of_service')->count()]]);
    }

    public function fleetFinances(int $busId, string $departureCode)
    {
        return response()->json(DB::table('bus_expenses')->where('bus_id', $busId)->where('departure_code', $departureCode)->latest('expense_date')->get());
    }

    public function busDocuments(int $busId, Request $request)
    {
        return response()->json(DB::table('bus_documents')->where('bus_id', $busId)->latest('expiry_date')->paginate($request->integer('per_page', 50)));
    }

    public function storeBusDocument(Request $request, int $busId)
    {
        $data = $request->validate(['document_type' => 'required|string', 'title' => 'required|string', 'reference_number' => 'nullable|string', 'provider' => 'nullable|string', 'issue_date' => 'nullable|date', 'expiry_date' => 'required|date', 'cost_mad' => 'nullable|numeric', 'file_url' => 'nullable|string', 'notes' => 'nullable|string']);
        $data['bus_id'] = $busId;
        $data['public_id'] = (string) Str::uuid();
        $data['created_at'] = now();
        $data['updated_at'] = now();
        $id = DB::table('bus_documents')->insertGetId($data);
        return response()->json(DB::table('bus_documents')->find($id), 201);
    }

    public function deleteBusDocument(int $busId, int $documentId)
    {
        DB::table('bus_documents')->where('id', $documentId)->where('bus_id', $busId)->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

    public function busDepartures(int $busId, Request $request)
    {
        return response()->json(DB::table('bus_departures')->where('bus_id', $busId)->latest('start_date')->paginate($request->integer('per_page', 50)));
    }

    public function storeBusDeparture(Request $request, int $busId)
    {
        $data = $request->validate(['departure_code' => 'required|string', 'trip_name' => 'required|string', 'route_trajet' => 'required|string', 'start_date' => 'required|date', 'end_date' => 'required|date', 'driver_name' => 'nullable|string', 'driver_phone' => 'nullable|string', 'status' => 'nullable|string', 'notes' => 'nullable|string']);
        $data['bus_id'] = $busId;
        $data['created_at'] = now();
        $id = DB::table('bus_departures')->insertGetId($data);
        return response()->json(DB::table('bus_departures')->find($id), 201);
    }

    public function deleteBusDeparture(int $busId, int $departureId)
    {
        DB::table('bus_departures')->where('id', $departureId)->where('bus_id', $busId)->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

    public function storeBusExpense(Request $request, int $busId, string $departureCode)
    {
        $data = $request->validate(['category' => 'required|string', 'title' => 'required|string', 'amount_mad' => 'required|numeric', 'expense_date' => 'required|date', 'supplier' => 'nullable|string', 'invoice_ref' => 'nullable|string', 'payment_method' => 'nullable|string', 'recorded_by' => 'nullable|string', 'notes' => 'nullable|string']);
        $data['bus_id'] = $busId;
        $data['departure_code'] = $departureCode;
        $data['public_id'] = (string) Str::uuid();
        $data['created_at'] = now();
        $id = DB::table('bus_expenses')->insertGetId($data);
        return response()->json(DB::table('bus_expenses')->find($id), 201);
    }

    public function deleteBusExpense(int $busId, int $expenseId)
    {
        DB::table('bus_expenses')->where('id', $expenseId)->where('bus_id', $busId)->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

    public function adminLogin(Request $request)
    {
        $credentials = $request->validate(['email' => 'required|email', 'password' => 'required|string']);
        $user = DB::table('users')->where('email', $credentials['email'])->first();
        if (!$user || !Hash::check($credentials['password'], $user->password_hash ?? '')) return response()->json(['message' => 'Invalid credentials'], 401);
        return response()->json(['success' => true, 'token' => Str::random(64), 'user' => $user]);
    }
}
