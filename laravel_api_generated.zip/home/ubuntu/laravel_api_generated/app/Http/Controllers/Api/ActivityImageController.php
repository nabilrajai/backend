<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ActivityImage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ActivityImageController extends Controller
{
    private string $model = ActivityImage::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'activity_id' => 'required|integer',
            'url' => 'required|string',
            'name' => 'nullable|string',
            'is_cover' => 'required|boolean',
            'sort_order' => 'required|integer',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    public function show($id)
    {
        return response()->json($this->model::findOrFail($id));
    }

    public function update(Request $request, $id)
    {
        $record = $this->model::findOrFail($id);
        $validated = $request->validate([
            'activity_id' => 'sometimes|integer',
            'url' => 'sometimes|string',
            'name' => 'sometimes|string',
            'is_cover' => 'sometimes|boolean',
            'sort_order' => 'sometimes|integer',
        ]);
        $record->update($validated);
        return response()->json($record->fresh());
    }

    public function destroy($id)
    {
        $record = $this->model::findOrFail($id);
        $record->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

    public function byActivity($activity_id)
    {
        return response()->json($this->model::where('activity_id', $activity_id)->paginate(request()->integer('per_page', 15)));
    }

}

