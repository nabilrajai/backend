<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\TripActivitySchedule;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class TripActivityScheduleController extends Controller
{
    private string $model = TripActivitySchedule::class;

    public function index(Request $request)
    {
        return response()->json($this->model::query()->paginate($request->integer('per_page', 15)));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'trip_day_id' => 'required|integer',
            'activity_id' => 'nullable|integer',
            'activity_name' => 'required|string',
            'category' => 'nullable|string',
            'start_time' => 'nullable',
            'duration_minutes' => 'nullable|integer',
            'location' => 'nullable|string',
            'guide_name' => 'nullable|string',
            'status' => 'required|in:confirmed,pending,optional,confirmed',
            'notes' => 'nullable|string',
            'color' => 'nullable|string',
        ]);
        return response()->json($this->model::create($validated), 201);
    }

    public function show($id)
    {
        return response()->json($this->model::findOrFail($id));
    }

    public function update(Request $request, $id)
    {
        $record = $this->model::findOrFail($id);
        $validated = $request->validate([
            'trip_day_id' => 'sometimes|integer',
            'activity_id' => 'sometimes|integer',
            'activity_name' => 'sometimes|string',
            'category' => 'sometimes|string',
            'start_time' => 'sometimes',
            'duration_minutes' => 'sometimes|integer',
            'location' => 'sometimes|string',
            'guide_name' => 'sometimes|string',
            'status' => 'sometimes|in:confirmed,pending,optional,confirmed',
            'notes' => 'sometimes|string',
            'color' => 'sometimes|string',
        ]);
        $record->update($validated);
        return response()->json($record->fresh());
    }

    public function destroy($id)
    {
        $record = $this->model::findOrFail($id);
        $record->delete();
        return response()->json(['message' => 'Deleted successfully']);
    }

    public function byTripDay($trip_day_id)
    {
        return response()->json($this->model::where('trip_day_id', $trip_day_id)->paginate(request()->integer('per_page', 15)));
    }

}

