-- Yallah Maana B2B bus-rental extension
-- Run this once against the same database as the existing schema.

CREATE TABLE IF NOT EXISTS `b2b_clients` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `public_id` char(36) NOT NULL,
  `company_name` varchar(220) NOT NULL,
  `contact_name` varchar(160) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(60) NOT NULL,
  `tax_id` varchar(100) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `city` varchar(120) DEFAULT NULL,
  `country` varchar(120) NOT NULL DEFAULT 'Morocco',
  `notes` text DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `b2b_clients_public_id_unique` (`public_id`),
  KEY `b2b_clients_company_idx` (`company_name`),
  KEY `b2b_clients_status_idx` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `bus_rentals` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `public_id` char(36) NOT NULL,
  `b2b_client_id` bigint unsigned NOT NULL,
  `bus_id` bigint unsigned NOT NULL,
  `contract_reference` varchar(100) NOT NULL,
  `trip_name` varchar(220) NOT NULL,
  `pickup_location` varchar(255) NOT NULL,
  `destination` varchar(255) NOT NULL,
  `start_at` datetime NOT NULL,
  `end_at` datetime NOT NULL,
  `agreed_price_mad` decimal(12,2) NOT NULL DEFAULT 0.00,
  `status` enum('draft','confirmed','in_progress','completed','cancelled') NOT NULL DEFAULT 'draft',
  `driver_included` tinyint(1) NOT NULL DEFAULT 1,
  `driver_name` varchar(160) DEFAULT NULL,
  `driver_phone` varchar(60) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` bigint unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `bus_rentals_public_id_unique` (`public_id`),
  UNIQUE KEY `bus_rentals_reference_unique` (`contract_reference`),
  KEY `bus_rentals_client_idx` (`b2b_client_id`),
  KEY `bus_rentals_bus_dates_idx` (`bus_id`,`start_at`,`end_at`),
  KEY `bus_rentals_status_idx` (`status`),
  CONSTRAINT `bus_rentals_client_fk` FOREIGN KEY (`b2b_client_id`) REFERENCES `b2b_clients` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `bus_rentals_bus_fk` FOREIGN KEY (`bus_id`) REFERENCES `buses` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `bus_rentals_created_by_fk` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `bus_rental_expenses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `public_id` char(36) NOT NULL,
  `bus_rental_id` bigint unsigned NOT NULL,
  `category` enum('fuel','toll','driver','maintenance','parking','other') NOT NULL DEFAULT 'fuel',
  `title` varchar(200) NOT NULL,
  `amount_mad` decimal(12,2) NOT NULL DEFAULT 0.00,
  `expense_date` date NOT NULL,
  `supplier` varchar(160) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `bus_rental_expenses_rental_idx` (`bus_rental_id`),
  CONSTRAINT `bus_rental_expenses_rental_fk` FOREIGN KEY (`bus_rental_id`) REFERENCES `bus_rentals` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
