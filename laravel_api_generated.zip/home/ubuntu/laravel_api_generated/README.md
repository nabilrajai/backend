# Generated Laravel API layer

Generated from `u813200012_yallahmana.sql`. This output intentionally contains only models, API controllers, and explicit `routes/api.php` routes.

The `database/b2b_bus_rentals.sql` script adds the B2B client, bus rental, and rental expense tables. Run it after the original schema before using the B2B rental page.

- Models: `53`
- Controllers: `53`
- CRUD routes are explicitly listed; no `apiResource` is used.
- Foreign-key lookup routes use `/resource/by-foreign_column/{value}`.
- Composite-key tables (destination_trips, role_permissions, user_roles) use `/resource/by-key` and require all key fields in the request.

Copy `app/Models`, `app/Http/Controllers/Api`, and `routes/api.php` into a Laravel project. Add the controller imports at the top of `routes/api.php` if your project does not already use grouped imports.
