<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\AdminApiController;
use App\Http\Controllers\Api\B2bRentalController;
use App\Http\Controllers\Api\AccommodationController;
use App\Http\Controllers\Api\ActivityController;
use App\Http\Controllers\Api\ActivityImageController;
use App\Http\Controllers\Api\AdminUserController;
use App\Http\Controllers\Api\AuditLogController;
use App\Http\Controllers\Api\BusController;
use App\Http\Controllers\Api\BusDepartureController;
use App\Http\Controllers\Api\BusDocumentController;
use App\Http\Controllers\Api\BusExpenseController;
use App\Http\Controllers\Api\CashEntryController;
use App\Http\Controllers\Api\CashSessionController;
use App\Http\Controllers\Api\CategoryController;
use App\Http\Controllers\Api\CityController;
use App\Http\Controllers\Api\ContactSubmissionController;
use App\Http\Controllers\Api\CustomerController;
use App\Http\Controllers\Api\DepartureController;
use App\Http\Controllers\Api\DepartureActivityOrderController;
use App\Http\Controllers\Api\DeparturePassengerController;
use App\Http\Controllers\Api\DeparturePresenceController;
use App\Http\Controllers\Api\DestinationController;
use App\Http\Controllers\Api\DestinationTripController;
use App\Http\Controllers\Api\EmailTemplateController;
use App\Http\Controllers\Api\GalleryController;
use App\Http\Controllers\Api\GalleryParticipantController;
use App\Http\Controllers\Api\GalleryPhotoController;
use App\Http\Controllers\Api\LoyaltyMemberController;
use App\Http\Controllers\Api\LoyaltyRewardController;
use App\Http\Controllers\Api\LoyaltyTransactionController;
use App\Http\Controllers\Api\NotificationController;
use App\Http\Controllers\Api\PaymentController;
use App\Http\Controllers\Api\PaymentDocumentController;
use App\Http\Controllers\Api\PaymentDocumentItemController;
use App\Http\Controllers\Api\PermissionController;
use App\Http\Controllers\Api\PromoCodeController;
use App\Http\Controllers\Api\ReservationController;
use App\Http\Controllers\Api\ReservationTimelineController;
use App\Http\Controllers\Api\ReservationTravelerController;
use App\Http\Controllers\Api\RewardRedemptionController;
use App\Http\Controllers\Api\RoleController;
use App\Http\Controllers\Api\RolePermissionController;
use App\Http\Controllers\Api\RoomAssignmentController;
use App\Http\Controllers\Api\SessionController;
use App\Http\Controllers\Api\SettingController;
use App\Http\Controllers\Api\SupportTicketController;
use App\Http\Controllers\Api\TripController;
use App\Http\Controllers\Api\TripActivityScheduleController;
use App\Http\Controllers\Api\TripDayController;
use App\Http\Controllers\Api\TripFaqController;
use App\Http\Controllers\Api\TripImageController;
use App\Http\Controllers\Api\TripReviewController;
use App\Http\Controllers\Api\UserController;
use App\Http\Controllers\Api\UserRoleController;
use App\Http\Controllers\Api\VehicleController;

// accommodations
Route::get('/accommodations', [AccommodationController::class, 'index']);
Route::post('/accommodations', [AccommodationController::class, 'store']);
Route::get('/accommodations/{id}', [AccommodationController::class, 'show']);
Route::put('/accommodations/{id}', [AccommodationController::class, 'update']);
Route::patch('/accommodations/{id}', [AccommodationController::class, 'update']);
Route::delete('/accommodations/{id}', [AccommodationController::class, 'destroy']);
Route::get('/accommodations/by-city_id/{city_id}', [AccommodationController::class, 'byCity']);

// activities
Route::get('/activities', [ActivityController::class, 'index']);
Route::post('/activities', [ActivityController::class, 'store']);
Route::get('/activities/{id}', [ActivityController::class, 'show']);
Route::put('/activities/{id}', [ActivityController::class, 'update']);
Route::patch('/activities/{id}', [ActivityController::class, 'update']);
Route::delete('/activities/{id}', [ActivityController::class, 'destroy']);
Route::get('/activities/by-created_by/{created_by}', [ActivityController::class, 'byUser']);

// activity_images
Route::get('/activity-images', [ActivityImageController::class, 'index']);
Route::post('/activity-images', [ActivityImageController::class, 'store']);
Route::get('/activity-images/{id}', [ActivityImageController::class, 'show']);
Route::put('/activity-images/{id}', [ActivityImageController::class, 'update']);
Route::patch('/activity-images/{id}', [ActivityImageController::class, 'update']);
Route::delete('/activity-images/{id}', [ActivityImageController::class, 'destroy']);
Route::get('/activity-images/by-activity_id/{activity_id}', [ActivityImageController::class, 'byActivity']);

// admin_users
Route::get('/admin-users', [AdminUserController::class, 'index']);
Route::post('/admin-users', [AdminUserController::class, 'store']);
Route::get('/admin-users/{user_id}', [AdminUserController::class, 'show']);
Route::put('/admin-users/{user_id}', [AdminUserController::class, 'update']);
Route::patch('/admin-users/{user_id}', [AdminUserController::class, 'update']);
Route::delete('/admin-users/{user_id}', [AdminUserController::class, 'destroy']);
Route::get('/admin-users/by-user_id/{user_id}', [AdminUserController::class, 'byUser']);

// audit_logs
Route::get('/audit-logs', [AuditLogController::class, 'index']);
Route::post('/audit-logs', [AuditLogController::class, 'store']);
Route::get('/audit-logs/{id}', [AuditLogController::class, 'show']);
Route::put('/audit-logs/{id}', [AuditLogController::class, 'update']);
Route::patch('/audit-logs/{id}', [AuditLogController::class, 'update']);
Route::delete('/audit-logs/{id}', [AuditLogController::class, 'destroy']);
Route::get('/audit-logs/by-actor_user_id/{actor_user_id}', [AuditLogController::class, 'byUser']);

// buses
Route::get('/buses', [BusController::class, 'index']);
Route::post('/buses', [BusController::class, 'store']);
Route::get('/buses/{id}', [BusController::class, 'show']);
Route::put('/buses/{id}', [BusController::class, 'update']);
Route::patch('/buses/{id}', [BusController::class, 'update']);
Route::delete('/buses/{id}', [BusController::class, 'destroy']);

// bus_departures
Route::get('/bus-departures', [BusDepartureController::class, 'index']);
Route::post('/bus-departures', [BusDepartureController::class, 'store']);
Route::get('/bus-departures/{id}', [BusDepartureController::class, 'show']);
Route::put('/bus-departures/{id}', [BusDepartureController::class, 'update']);
Route::patch('/bus-departures/{id}', [BusDepartureController::class, 'update']);
Route::delete('/bus-departures/{id}', [BusDepartureController::class, 'destroy']);

// bus_documents
Route::get('/bus-documents', [BusDocumentController::class, 'index']);
Route::post('/bus-documents', [BusDocumentController::class, 'store']);
Route::get('/bus-documents/{id}', [BusDocumentController::class, 'show']);
Route::put('/bus-documents/{id}', [BusDocumentController::class, 'update']);
Route::patch('/bus-documents/{id}', [BusDocumentController::class, 'update']);
Route::delete('/bus-documents/{id}', [BusDocumentController::class, 'destroy']);

// bus_expenses
Route::get('/bus-expenses', [BusExpenseController::class, 'index']);
Route::post('/bus-expenses', [BusExpenseController::class, 'store']);
Route::get('/bus-expenses/{id}', [BusExpenseController::class, 'show']);
Route::put('/bus-expenses/{id}', [BusExpenseController::class, 'update']);
Route::patch('/bus-expenses/{id}', [BusExpenseController::class, 'update']);
Route::delete('/bus-expenses/{id}', [BusExpenseController::class, 'destroy']);

// cash_entries
Route::get('/cash-entries', [CashEntryController::class, 'index']);
Route::post('/cash-entries', [CashEntryController::class, 'store']);
Route::get('/cash-entries/{id}', [CashEntryController::class, 'show']);
Route::put('/cash-entries/{id}', [CashEntryController::class, 'update']);
Route::patch('/cash-entries/{id}', [CashEntryController::class, 'update']);
Route::delete('/cash-entries/{id}', [CashEntryController::class, 'destroy']);
Route::get('/cash-entries/by-session_id/{session_id}', [CashEntryController::class, 'byCashSession']);

// cash_sessions
Route::get('/cash-sessions', [CashSessionController::class, 'index']);
Route::post('/cash-sessions', [CashSessionController::class, 'store']);
Route::get('/cash-sessions/{id}', [CashSessionController::class, 'show']);
Route::put('/cash-sessions/{id}', [CashSessionController::class, 'update']);
Route::patch('/cash-sessions/{id}', [CashSessionController::class, 'update']);
Route::delete('/cash-sessions/{id}', [CashSessionController::class, 'destroy']);
Route::get('/cash-sessions/by-opened_by/{opened_by}', [CashSessionController::class, 'byUser']);

// categories
Route::get('/categories', [CategoryController::class, 'index']);
Route::post('/categories', [CategoryController::class, 'store']);
Route::get('/categories/{id}', [CategoryController::class, 'show']);
Route::put('/categories/{id}', [CategoryController::class, 'update']);
Route::patch('/categories/{id}', [CategoryController::class, 'update']);
Route::delete('/categories/{id}', [CategoryController::class, 'destroy']);

// cities
Route::get('/cities', [CityController::class, 'index']);
Route::post('/cities', [CityController::class, 'store']);
Route::get('/cities/{id}', [CityController::class, 'show']);
Route::put('/cities/{id}', [CityController::class, 'update']);
Route::patch('/cities/{id}', [CityController::class, 'update']);
Route::delete('/cities/{id}', [CityController::class, 'destroy']);

// contact_submissions
Route::get('/contact-submissions', [ContactSubmissionController::class, 'index']);
Route::post('/contact-submissions', [ContactSubmissionController::class, 'store']);
Route::get('/contact-submissions/{id}', [ContactSubmissionController::class, 'show']);
Route::put('/contact-submissions/{id}', [ContactSubmissionController::class, 'update']);
Route::patch('/contact-submissions/{id}', [ContactSubmissionController::class, 'update']);
Route::delete('/contact-submissions/{id}', [ContactSubmissionController::class, 'destroy']);
Route::get('/contact-submissions/by-assigned_to/{assigned_to}', [ContactSubmissionController::class, 'byUser']);

// customers
Route::get('/customers', [CustomerController::class, 'index']);
Route::post('/customers', [CustomerController::class, 'store']);
Route::get('/customers/{id}', [CustomerController::class, 'show']);
Route::put('/customers/{id}', [CustomerController::class, 'update']);
Route::patch('/customers/{id}', [CustomerController::class, 'update']);
Route::delete('/customers/{id}', [CustomerController::class, 'destroy']);

// departures
Route::get('/departures', [DepartureController::class, 'index']);
Route::post('/departures', [DepartureController::class, 'store']);
Route::get('/departures/{id}', [DepartureController::class, 'show']);
Route::put('/departures/{id}', [DepartureController::class, 'update']);
Route::patch('/departures/{id}', [DepartureController::class, 'update']);
Route::delete('/departures/{id}', [DepartureController::class, 'destroy']);
Route::get('/departures/by-trip_id/{trip_id}', [DepartureController::class, 'byTrip']);

// departure_activity_orders
Route::get('/departure-activity-orders', [DepartureActivityOrderController::class, 'index']);
Route::post('/departure-activity-orders', [DepartureActivityOrderController::class, 'store']);
Route::get('/departure-activity-orders/{id}', [DepartureActivityOrderController::class, 'show']);
Route::put('/departure-activity-orders/{id}', [DepartureActivityOrderController::class, 'update']);
Route::patch('/departure-activity-orders/{id}', [DepartureActivityOrderController::class, 'update']);
Route::delete('/departure-activity-orders/{id}', [DepartureActivityOrderController::class, 'destroy']);
Route::get('/departure-activity-orders/by-departure_id/{departure_id}', [DepartureActivityOrderController::class, 'byDeparture']);

// departure_passengers
Route::get('/departure-passengers', [DeparturePassengerController::class, 'index']);
Route::post('/departure-passengers', [DeparturePassengerController::class, 'store']);
Route::get('/departure-passengers/{id}', [DeparturePassengerController::class, 'show']);
Route::put('/departure-passengers/{id}', [DeparturePassengerController::class, 'update']);
Route::patch('/departure-passengers/{id}', [DeparturePassengerController::class, 'update']);
Route::delete('/departure-passengers/{id}', [DeparturePassengerController::class, 'destroy']);
Route::get('/departure-passengers/by-departure_id/{departure_id}', [DeparturePassengerController::class, 'byDeparture']);

// departure_presence
Route::get('/departure-presence', [DeparturePresenceController::class, 'index']);
Route::post('/departure-presence', [DeparturePresenceController::class, 'store']);
Route::get('/departure-presence/{id}', [DeparturePresenceController::class, 'show']);
Route::put('/departure-presence/{id}', [DeparturePresenceController::class, 'update']);
Route::patch('/departure-presence/{id}', [DeparturePresenceController::class, 'update']);
Route::delete('/departure-presence/{id}', [DeparturePresenceController::class, 'destroy']);
Route::get('/departure-presence/by-departure_id/{departure_id}', [DeparturePresenceController::class, 'byDeparture']);

// destinations
Route::get('/destinations', [DestinationController::class, 'index']);
Route::post('/destinations', [DestinationController::class, 'store']);
Route::get('/destinations/{id}', [DestinationController::class, 'show']);
Route::put('/destinations/{id}', [DestinationController::class, 'update']);
Route::patch('/destinations/{id}', [DestinationController::class, 'update']);
Route::delete('/destinations/{id}', [DestinationController::class, 'destroy']);
Route::get('/destinations/by-category_id/{category_id}', [DestinationController::class, 'byCategory']);

// destination_trips
Route::get('/destination-trips', [DestinationTripController::class, 'index']);
Route::post('/destination-trips', [DestinationTripController::class, 'store']);
// Composite key (destination_id, trip_id): pass key fields as query/body parameters.
Route::get('/destination-trips/by-key', [DestinationTripController::class, 'show']);
Route::put('/destination-trips/by-key', [DestinationTripController::class, 'update']);
Route::patch('/destination-trips/by-key', [DestinationTripController::class, 'update']);
Route::delete('/destination-trips/by-key', [DestinationTripController::class, 'destroy']);
Route::get('/destination-trips/by-destination_id/{destination_id}', [DestinationTripController::class, 'byDestination']);

// email_templates
Route::get('/email-templates', [EmailTemplateController::class, 'index']);
Route::post('/email-templates', [EmailTemplateController::class, 'store']);
Route::get('/email-templates/{id}', [EmailTemplateController::class, 'show']);
Route::put('/email-templates/{id}', [EmailTemplateController::class, 'update']);
Route::patch('/email-templates/{id}', [EmailTemplateController::class, 'update']);
Route::delete('/email-templates/{id}', [EmailTemplateController::class, 'destroy']);
Route::get('/email-templates/by-updated_by/{updated_by}', [EmailTemplateController::class, 'byUser']);

// galleries
Route::get('/galleries', [GalleryController::class, 'index']);
Route::post('/galleries', [GalleryController::class, 'store']);
Route::get('/galleries/{id}', [GalleryController::class, 'show']);
Route::put('/galleries/{id}', [GalleryController::class, 'update']);
Route::patch('/galleries/{id}', [GalleryController::class, 'update']);
Route::delete('/galleries/{id}', [GalleryController::class, 'destroy']);
Route::get('/galleries/by-departure_id/{departure_id}', [GalleryController::class, 'byDeparture']);

// gallery_participants
Route::get('/gallery-participants', [GalleryParticipantController::class, 'index']);
Route::post('/gallery-participants', [GalleryParticipantController::class, 'store']);
Route::get('/gallery-participants/{id}', [GalleryParticipantController::class, 'show']);
Route::put('/gallery-participants/{id}', [GalleryParticipantController::class, 'update']);
Route::patch('/gallery-participants/{id}', [GalleryParticipantController::class, 'update']);
Route::delete('/gallery-participants/{id}', [GalleryParticipantController::class, 'destroy']);
Route::get('/gallery-participants/by-gallery_id/{gallery_id}', [GalleryParticipantController::class, 'byGallery']);

// gallery_photos
Route::get('/gallery-photos', [GalleryPhotoController::class, 'index']);
Route::post('/gallery-photos', [GalleryPhotoController::class, 'store']);
Route::get('/gallery-photos/{id}', [GalleryPhotoController::class, 'show']);
Route::put('/gallery-photos/{id}', [GalleryPhotoController::class, 'update']);
Route::patch('/gallery-photos/{id}', [GalleryPhotoController::class, 'update']);
Route::delete('/gallery-photos/{id}', [GalleryPhotoController::class, 'destroy']);
Route::get('/gallery-photos/by-gallery_id/{gallery_id}', [GalleryPhotoController::class, 'byGallery']);

// loyalty_members
Route::get('/loyalty-members', [LoyaltyMemberController::class, 'index']);
Route::post('/loyalty-members', [LoyaltyMemberController::class, 'store']);
Route::get('/loyalty-members/{id}', [LoyaltyMemberController::class, 'show']);
Route::put('/loyalty-members/{id}', [LoyaltyMemberController::class, 'update']);
Route::patch('/loyalty-members/{id}', [LoyaltyMemberController::class, 'update']);
Route::delete('/loyalty-members/{id}', [LoyaltyMemberController::class, 'destroy']);
Route::get('/loyalty-members/by-customer_id/{customer_id}', [LoyaltyMemberController::class, 'byCustomer']);

// loyalty_rewards
Route::get('/loyalty-rewards', [LoyaltyRewardController::class, 'index']);
Route::post('/loyalty-rewards', [LoyaltyRewardController::class, 'store']);
Route::get('/loyalty-rewards/{id}', [LoyaltyRewardController::class, 'show']);
Route::put('/loyalty-rewards/{id}', [LoyaltyRewardController::class, 'update']);
Route::patch('/loyalty-rewards/{id}', [LoyaltyRewardController::class, 'update']);
Route::delete('/loyalty-rewards/{id}', [LoyaltyRewardController::class, 'destroy']);
Route::get('/loyalty-rewards/by-created_by/{created_by}', [LoyaltyRewardController::class, 'byUser']);

// loyalty_transactions
Route::get('/loyalty-transactions', [LoyaltyTransactionController::class, 'index']);
Route::post('/loyalty-transactions', [LoyaltyTransactionController::class, 'store']);
Route::get('/loyalty-transactions/{id}', [LoyaltyTransactionController::class, 'show']);
Route::put('/loyalty-transactions/{id}', [LoyaltyTransactionController::class, 'update']);
Route::patch('/loyalty-transactions/{id}', [LoyaltyTransactionController::class, 'update']);
Route::delete('/loyalty-transactions/{id}', [LoyaltyTransactionController::class, 'destroy']);
Route::get('/loyalty-transactions/by-loyalty_member_id/{loyalty_member_id}', [LoyaltyTransactionController::class, 'byLoyaltyMember']);

// notifications
Route::get('/notifications', [NotificationController::class, 'index']);
Route::post('/notifications', [NotificationController::class, 'store']);
Route::get('/notifications/{id}', [NotificationController::class, 'show']);
Route::put('/notifications/{id}', [NotificationController::class, 'update']);
Route::patch('/notifications/{id}', [NotificationController::class, 'update']);
Route::delete('/notifications/{id}', [NotificationController::class, 'destroy']);
Route::get('/notifications/by-user_id/{user_id}', [NotificationController::class, 'byUser']);

// payments
Route::get('/payments', [PaymentController::class, 'index']);
Route::post('/payments', [PaymentController::class, 'store']);
Route::get('/payments/{id}', [PaymentController::class, 'show']);
Route::put('/payments/{id}', [PaymentController::class, 'update']);
Route::patch('/payments/{id}', [PaymentController::class, 'update']);
Route::delete('/payments/{id}', [PaymentController::class, 'destroy']);
Route::get('/payments/by-reservation_id/{reservation_id}', [PaymentController::class, 'byReservation']);

// payment_documents
Route::get('/payment-documents', [PaymentDocumentController::class, 'index']);
Route::post('/payment-documents', [PaymentDocumentController::class, 'store']);
Route::get('/payment-documents/{id}', [PaymentDocumentController::class, 'show']);
Route::put('/payment-documents/{id}', [PaymentDocumentController::class, 'update']);
Route::patch('/payment-documents/{id}', [PaymentDocumentController::class, 'update']);
Route::delete('/payment-documents/{id}', [PaymentDocumentController::class, 'destroy']);
Route::get('/payment-documents/by-customer_id/{customer_id}', [PaymentDocumentController::class, 'byCustomer']);

// payment_document_items
Route::get('/payment-document-items', [PaymentDocumentItemController::class, 'index']);
Route::post('/payment-document-items', [PaymentDocumentItemController::class, 'store']);
Route::get('/payment-document-items/{id}', [PaymentDocumentItemController::class, 'show']);
Route::put('/payment-document-items/{id}', [PaymentDocumentItemController::class, 'update']);
Route::patch('/payment-document-items/{id}', [PaymentDocumentItemController::class, 'update']);
Route::delete('/payment-document-items/{id}', [PaymentDocumentItemController::class, 'destroy']);
Route::get('/payment-document-items/by-document_id/{document_id}', [PaymentDocumentItemController::class, 'byPaymentDocument']);

// permissions
Route::get('/permissions', [PermissionController::class, 'index']);
Route::post('/permissions', [PermissionController::class, 'store']);
Route::get('/permissions/{id}', [PermissionController::class, 'show']);
Route::put('/permissions/{id}', [PermissionController::class, 'update']);
Route::patch('/permissions/{id}', [PermissionController::class, 'update']);
Route::delete('/permissions/{id}', [PermissionController::class, 'destroy']);

// promo_codes
Route::get('/promo-codes', [PromoCodeController::class, 'index']);
Route::post('/promo-codes', [PromoCodeController::class, 'store']);
Route::get('/promo-codes/{id}', [PromoCodeController::class, 'show']);
Route::put('/promo-codes/{id}', [PromoCodeController::class, 'update']);
Route::patch('/promo-codes/{id}', [PromoCodeController::class, 'update']);
Route::delete('/promo-codes/{id}', [PromoCodeController::class, 'destroy']);

// reservations
Route::get('/reservations', [ReservationController::class, 'index']);
Route::post('/reservations', [ReservationController::class, 'store']);
Route::get('/reservations/{id}', [ReservationController::class, 'show']);
Route::put('/reservations/{id}', [ReservationController::class, 'update']);
Route::patch('/reservations/{id}', [ReservationController::class, 'update']);
Route::delete('/reservations/{id}', [ReservationController::class, 'destroy']);
Route::get('/reservations/by-customer_id/{customer_id}', [ReservationController::class, 'byCustomer']);

// reservation_timeline
Route::get('/reservation-timeline', [ReservationTimelineController::class, 'index']);
Route::post('/reservation-timeline', [ReservationTimelineController::class, 'store']);
Route::get('/reservation-timeline/{id}', [ReservationTimelineController::class, 'show']);
Route::put('/reservation-timeline/{id}', [ReservationTimelineController::class, 'update']);
Route::patch('/reservation-timeline/{id}', [ReservationTimelineController::class, 'update']);
Route::delete('/reservation-timeline/{id}', [ReservationTimelineController::class, 'destroy']);
Route::get('/reservation-timeline/by-reservation_id/{reservation_id}', [ReservationTimelineController::class, 'byReservation']);

// reservation_travelers
Route::get('/reservation-travelers', [ReservationTravelerController::class, 'index']);
Route::post('/reservation-travelers', [ReservationTravelerController::class, 'store']);
Route::get('/reservation-travelers/{id}', [ReservationTravelerController::class, 'show']);
Route::put('/reservation-travelers/{id}', [ReservationTravelerController::class, 'update']);
Route::patch('/reservation-travelers/{id}', [ReservationTravelerController::class, 'update']);
Route::delete('/reservation-travelers/{id}', [ReservationTravelerController::class, 'destroy']);
Route::get('/reservation-travelers/by-reservation_id/{reservation_id}', [ReservationTravelerController::class, 'byReservation']);

// reward_redemptions
Route::get('/reward-redemptions', [RewardRedemptionController::class, 'index']);
Route::post('/reward-redemptions', [RewardRedemptionController::class, 'store']);
Route::get('/reward-redemptions/{id}', [RewardRedemptionController::class, 'show']);
Route::put('/reward-redemptions/{id}', [RewardRedemptionController::class, 'update']);
Route::patch('/reward-redemptions/{id}', [RewardRedemptionController::class, 'update']);
Route::delete('/reward-redemptions/{id}', [RewardRedemptionController::class, 'destroy']);
Route::get('/reward-redemptions/by-loyalty_member_id/{loyalty_member_id}', [RewardRedemptionController::class, 'byLoyaltyMember']);

// roles
Route::get('/roles', [RoleController::class, 'index']);
Route::post('/roles', [RoleController::class, 'store']);
Route::get('/roles/{id}', [RoleController::class, 'show']);
Route::put('/roles/{id}', [RoleController::class, 'update']);
Route::patch('/roles/{id}', [RoleController::class, 'update']);
Route::delete('/roles/{id}', [RoleController::class, 'destroy']);

// role_permissions
Route::get('/role-permissions', [RolePermissionController::class, 'index']);
Route::post('/role-permissions', [RolePermissionController::class, 'store']);
// Composite key (role_id, permission_id): pass key fields as query/body parameters.
Route::get('/role-permissions/by-key', [RolePermissionController::class, 'show']);
Route::put('/role-permissions/by-key', [RolePermissionController::class, 'update']);
Route::patch('/role-permissions/by-key', [RolePermissionController::class, 'update']);
Route::delete('/role-permissions/by-key', [RolePermissionController::class, 'destroy']);
Route::get('/role-permissions/by-role_id/{role_id}', [RolePermissionController::class, 'byRole']);

// room_assignments
Route::get('/room-assignments', [RoomAssignmentController::class, 'index']);
Route::post('/room-assignments', [RoomAssignmentController::class, 'store']);
Route::get('/room-assignments/{id}', [RoomAssignmentController::class, 'show']);
Route::put('/room-assignments/{id}', [RoomAssignmentController::class, 'update']);
Route::patch('/room-assignments/{id}', [RoomAssignmentController::class, 'update']);
Route::delete('/room-assignments/{id}', [RoomAssignmentController::class, 'destroy']);
Route::get('/room-assignments/by-departure_id/{departure_id}', [RoomAssignmentController::class, 'byDeparture']);

// sessions
Route::get('/sessions', [SessionController::class, 'index']);
Route::post('/sessions', [SessionController::class, 'store']);
Route::get('/sessions/{id}', [SessionController::class, 'show']);
Route::put('/sessions/{id}', [SessionController::class, 'update']);
Route::patch('/sessions/{id}', [SessionController::class, 'update']);
Route::delete('/sessions/{id}', [SessionController::class, 'destroy']);
Route::get('/sessions/by-user_id/{user_id}', [SessionController::class, 'byUser']);

// settings
Route::get('/settings', [SettingController::class, 'index']);
Route::post('/settings', [SettingController::class, 'store']);
Route::get('/settings/{id}', [SettingController::class, 'show']);
Route::put('/settings/{id}', [SettingController::class, 'update']);
Route::patch('/settings/{id}', [SettingController::class, 'update']);
Route::delete('/settings/{id}', [SettingController::class, 'destroy']);
Route::get('/settings/by-updated_by/{updated_by}', [SettingController::class, 'byUser']);

// support_tickets
Route::get('/support-tickets', [SupportTicketController::class, 'index']);
Route::post('/support-tickets', [SupportTicketController::class, 'store']);
Route::get('/support-tickets/{id}', [SupportTicketController::class, 'show']);
Route::put('/support-tickets/{id}', [SupportTicketController::class, 'update']);
Route::patch('/support-tickets/{id}', [SupportTicketController::class, 'update']);
Route::delete('/support-tickets/{id}', [SupportTicketController::class, 'destroy']);
Route::get('/support-tickets/by-requester_user_id/{requester_user_id}', [SupportTicketController::class, 'byUser']);

// trips
Route::get('/trips', [TripController::class, 'index']);
Route::post('/trips', [TripController::class, 'store']);
Route::get('/trips/{id}', [TripController::class, 'show']);
Route::put('/trips/{id}', [TripController::class, 'update']);
Route::patch('/trips/{id}', [TripController::class, 'update']);
Route::delete('/trips/{id}', [TripController::class, 'destroy']);
Route::get('/trips/by-category_id/{category_id}', [TripController::class, 'byCategory']);

// trip_activity_schedule
Route::get('/trip-activity-schedule', [TripActivityScheduleController::class, 'index']);
Route::post('/trip-activity-schedule', [TripActivityScheduleController::class, 'store']);
Route::get('/trip-activity-schedule/{id}', [TripActivityScheduleController::class, 'show']);
Route::put('/trip-activity-schedule/{id}', [TripActivityScheduleController::class, 'update']);
Route::patch('/trip-activity-schedule/{id}', [TripActivityScheduleController::class, 'update']);
Route::delete('/trip-activity-schedule/{id}', [TripActivityScheduleController::class, 'destroy']);
Route::get('/trip-activity-schedule/by-trip_day_id/{trip_day_id}', [TripActivityScheduleController::class, 'byTripDay']);

// trip_days
Route::get('/trip-days', [TripDayController::class, 'index']);
Route::post('/trip-days', [TripDayController::class, 'store']);
Route::get('/trip-days/{id}', [TripDayController::class, 'show']);
Route::put('/trip-days/{id}', [TripDayController::class, 'update']);
Route::patch('/trip-days/{id}', [TripDayController::class, 'update']);
Route::delete('/trip-days/{id}', [TripDayController::class, 'destroy']);
Route::get('/trip-days/by-trip_id/{trip_id}', [TripDayController::class, 'byTrip']);

// trip_faqs
Route::get('/trip-faqs', [TripFaqController::class, 'index']);
Route::post('/trip-faqs', [TripFaqController::class, 'store']);
Route::get('/trip-faqs/{id}', [TripFaqController::class, 'show']);
Route::put('/trip-faqs/{id}', [TripFaqController::class, 'update']);
Route::patch('/trip-faqs/{id}', [TripFaqController::class, 'update']);
Route::delete('/trip-faqs/{id}', [TripFaqController::class, 'destroy']);
Route::get('/trip-faqs/by-trip_id/{trip_id}', [TripFaqController::class, 'byTrip']);

// trip_images
Route::get('/trip-images', [TripImageController::class, 'index']);
Route::post('/trip-images', [TripImageController::class, 'store']);
Route::get('/trip-images/{id}', [TripImageController::class, 'show']);
Route::put('/trip-images/{id}', [TripImageController::class, 'update']);
Route::patch('/trip-images/{id}', [TripImageController::class, 'update']);
Route::delete('/trip-images/{id}', [TripImageController::class, 'destroy']);
Route::get('/trip-images/by-trip_id/{trip_id}', [TripImageController::class, 'byTrip']);

// trip_reviews
Route::get('/trip-reviews', [TripReviewController::class, 'index']);
Route::post('/trip-reviews', [TripReviewController::class, 'store']);
Route::get('/trip-reviews/{id}', [TripReviewController::class, 'show']);
Route::put('/trip-reviews/{id}', [TripReviewController::class, 'update']);
Route::patch('/trip-reviews/{id}', [TripReviewController::class, 'update']);
Route::delete('/trip-reviews/{id}', [TripReviewController::class, 'destroy']);
Route::get('/trip-reviews/by-trip_id/{trip_id}', [TripReviewController::class, 'byTrip']);

// users
Route::get('/users', [UserController::class, 'index']);
Route::post('/users', [UserController::class, 'store']);
Route::get('/users/{id}', [UserController::class, 'show']);
Route::put('/users/{id}', [UserController::class, 'update']);
Route::patch('/users/{id}', [UserController::class, 'update']);
Route::delete('/users/{id}', [UserController::class, 'destroy']);

// user_roles
Route::get('/user-roles', [UserRoleController::class, 'index']);
Route::post('/user-roles', [UserRoleController::class, 'store']);
// Composite key (user_id, role_id): pass key fields as query/body parameters.
Route::get('/user-roles/by-key', [UserRoleController::class, 'show']);
Route::put('/user-roles/by-key', [UserRoleController::class, 'update']);
Route::patch('/user-roles/by-key', [UserRoleController::class, 'update']);
Route::delete('/user-roles/by-key', [UserRoleController::class, 'destroy']);
Route::get('/user-roles/by-user_id/{user_id}', [UserRoleController::class, 'byUser']);

// vehicles
Route::get('/vehicles', [VehicleController::class, 'index']);
Route::post('/vehicles', [VehicleController::class, 'store']);
Route::get('/vehicles/{id}', [VehicleController::class, 'show']);
Route::put('/vehicles/{id}', [VehicleController::class, 'update']);
Route::patch('/vehicles/{id}', [VehicleController::class, 'update']);
Route::delete('/vehicles/{id}', [VehicleController::class, 'destroy']);

// Admin compatibility and aggregate endpoints used by the React console.
Route::get('/health', [AdminApiController::class, 'health']);
Route::get('/admin/dashboard', [AdminApiController::class, 'dashboard']);
Route::get('/admin/menu-counts', [AdminApiController::class, 'menuCounts']);
Route::post('/auth/login', [AdminApiController::class, 'adminLogin']);
Route::post('/admin/database/connect', [AdminApiController::class, 'health']);
Route::get('/admin/caisse', function (\Illuminate\Http\Request $request) {
    return response()->json(\Illuminate\Support\Facades\DB::table('cash_entries')->paginate($request->integer('per_page', 50)));
});
Route::get('/admin/roles-permissions', function () {
    return response()->json(['roles' => \Illuminate\Support\Facades\DB::table('roles')->get(), 'permissions' => \Illuminate\Support\Facades\DB::table('permissions')->get()]);
});

Route::get('/admin/departures', [AdminApiController::class, 'departures']);
Route::get('/admin/departures/{departureId}/rooming', [AdminApiController::class, 'rooming']);
Route::post('/admin/departures/{departureId}/rooming', [AdminApiController::class, 'storeRoom']);
Route::put('/admin/departures/{departureId}/rooming/{roomId}', [AdminApiController::class, 'updateRoom']);
Route::delete('/admin/departures/{departureId}/rooming/{roomId}', [AdminApiController::class, 'deleteRoom']);
Route::get('/admin/departures/{departureId}/presence', [AdminApiController::class, 'presence']);
Route::put('/admin/departures/{departureId}/presence/{presenceId}', [AdminApiController::class, 'updatePresence']);
Route::get('/admin/departures/{departureId}/payments', [AdminApiController::class, 'departurePayments']);
Route::post('/admin/departures/{departureId}/payments', [AdminApiController::class, 'storeDeparturePayment']);
Route::get('/admin/departures/{departureId}/activities', [AdminApiController::class, 'departureActivities']);
Route::post('/admin/departures/{departureId}/activities', [AdminApiController::class, 'storeDepartureActivity']);
Route::delete('/admin/departures/{departureId}/activities/{activityId}', [AdminApiController::class, 'deleteDepartureActivity']);
Route::put('/admin/trips/{tripId}/programme', [AdminApiController::class, 'tripProgramme']);
Route::get('/admin/reservations/by-reference/{reference}', [AdminApiController::class, 'reservationByReference']);
Route::post('/admin/scanner/verify', [AdminApiController::class, 'scannerVerify']);
Route::post('/admin/scanner/checkin', [AdminApiController::class, 'scannerCheckin']);
Route::get('/admin/buses/summary', [AdminApiController::class, 'fleetSummary']);
Route::get('/admin/buses/{busId}/documents', [AdminApiController::class, 'busDocuments']);
Route::post('/admin/buses/{busId}/documents', [AdminApiController::class, 'storeBusDocument']);
Route::delete('/admin/buses/{busId}/documents/{documentId}', [AdminApiController::class, 'deleteBusDocument']);
Route::get('/admin/buses/{busId}/departures', [AdminApiController::class, 'busDepartures']);
Route::post('/admin/buses/{busId}/departures', [AdminApiController::class, 'storeBusDeparture']);
Route::delete('/admin/buses/{busId}/departures/{departureId}', [AdminApiController::class, 'deleteBusDeparture']);
Route::get('/admin/buses/{busId}/departures/{departureCode}/finances', [AdminApiController::class, 'fleetFinances']);
Route::post('/admin/buses/{busId}/departures/{departureCode}/expenses', [AdminApiController::class, 'storeBusExpense']);
Route::delete('/admin/buses/{busId}/expenses/{expenseId}', [AdminApiController::class, 'deleteBusExpense']);

// B2B bus rentals
Route::get('/admin/b2b/clients', [B2bRentalController::class, 'clients']);
Route::post('/admin/b2b/clients', [B2bRentalController::class, 'storeClient']);
Route::get('/admin/b2b/clients/{id}', [B2bRentalController::class, 'showClient']);
Route::put('/admin/b2b/clients/{id}', [B2bRentalController::class, 'updateClient']);
Route::patch('/admin/b2b/clients/{id}', [B2bRentalController::class, 'updateClient']);
Route::delete('/admin/b2b/clients/{id}', [B2bRentalController::class, 'deleteClient']);
Route::get('/admin/b2b/availability', [B2bRentalController::class, 'availability']);
Route::get('/admin/b2b/calendar', [B2bRentalController::class, 'calendar']);
Route::get('/admin/b2b/rentals', [B2bRentalController::class, 'rentals']);
Route::post('/admin/b2b/rentals', [B2bRentalController::class, 'storeRental']);
Route::get('/admin/b2b/rentals/{id}', [B2bRentalController::class, 'showRental']);
Route::put('/admin/b2b/rentals/{id}', [B2bRentalController::class, 'updateRental']);
Route::patch('/admin/b2b/rentals/{id}', [B2bRentalController::class, 'updateRental']);
Route::delete('/admin/b2b/rentals/{id}', [B2bRentalController::class, 'deleteRental']);
Route::get('/admin/b2b/rentals/{rentalId}/expenses', [B2bRentalController::class, 'expenses']);
Route::post('/admin/b2b/rentals/{rentalId}/expenses', [B2bRentalController::class, 'storeExpense']);
Route::delete('/admin/b2b/rentals/{rentalId}/expenses/{expenseId}', [B2bRentalController::class, 'deleteExpense']);
